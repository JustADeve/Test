const { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } = require("discord.js");
  const fetch = (...args) =>
    import("node-fetch").then(({ default: fetch }) => fetch(...args));
  
  module.exports = {
    data: new SlashCommandBuilder()
      .setName("advice")
      .setDescription("Get random advice."),
    async execute(interaction) {
      const data = await fetch("https://api.adviceslip.com/advice").then((res) =>
        res.json()
      );
      
      const embed = new EmbedBuilder()
      .setTimestamp()
      .setTitle('Advice Given')
      .addFields({ name: `Advice`, value: `> ${data.slip.advice}`})
      .setColor("#CAEEBE")

      await interaction.reply({embeds: [embed]});
    },
  };
  