const { SlashCommandBuilder } = require('@discordjs/builders')
const { EmbedBuilder, AttachmentBuilder } = require('discord.js')
const { profileImage } = require('discord-arts')
 const fetch = require ('node-fetch')

module.exports = {
    data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDMPermission(false)
    .addUserOption(option => option.setName('user').setDescription("The user who you are targetting.").setRequired(false))
    .setDescription('Get the information of a User within your Guild!'),
    async execute (interaction, client) {

        await interaction.deferReply();

        let user = interaction.options.getUser('user') || interaction.user;
        let member = await interaction.guild.members.cache.get(user.id)
       const icon = user.displayAvatarURL();
        const tag = user.tag;  
        let flags = user.flags.toArray();

        let roles = [];
        await Promise.all(member.roles.cache.map(async role => {
            if (role.id === interaction.guild.id) return;
            else {
                roles.push(role)
            }
        }))

        let badges = [];
        let extrabadges = [];
        let trustedbots = ['1011991517126201434', "1040565164921069608", "911833727301189684", "1096048779641237635", "985323221178011718"];
        let raidendeveloper = ['767383867031945236'];
        let zenithdeveloper = ['751708824796266558'];


        if (user.bot) extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371746001362944/application.png')
        if (trustedbots.includes(user.id)) extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371746374664232/trustedbot.png')
        if (trustedbots.includes(user.id)) badges.push('<:trusted_bot:1110906165010890762>')
        if (raidendeveloper.includes(user.id)) extrabadges.push('https://media.discordapp.net/attachments/1082188213071909014/1117118970001096704/Untitled_design_3.png?width=640&height=640')
        if (zenithdeveloper.includes(user.id)) extrabadges.push('https://media.discordapp.net/attachments/1115102010170167356/1119294865193304165/NitrixEXE.png?width=640&height=640')
        if (raidendeveloper.includes(user.id)) badges.push('<:raiden_developer:1117118362380677120>')
        if (user.bot) badges.push('<:discord_bot:1115100716139294851>')
        if (zenithdeveloper.includes(user.id)) badges.push('<:Zenith_Developer:1119295071557255248>')
        
        await Promise.all(flags.map (async badge => {

            if (badge === 'Staff') badges.push('<:discord_staff:1115110436858232853>')
            if (badge === 'Partner') badges.push('<:discord_partner:1115100727132569784>')
            if (badge === 'CertifiedModerator') badges.push('<:discord_moderator:1115100729372311582>')
            if (badge === 'Hypesquad') badges.push('<:discord_hypesquad:1115100723567411310>')
            if (badge === 'HypeSquadOnlineHouse1') badges.push('<:discord_bravery:1115110790727467008>')
            if (badge === 'HypeSquadOnlineHouse2') badges.push('<:discord_brilliance:1115100720312619008>')
            if (badge === 'HypeSquadOnlineHouse3') badges.push('<:discord_balance:1115100731859554314>')
            if (badge === 'BugHunterLevel1') badges.push('<:discord_bughunterlvl1:1109431699672141935>')
            if (badge === 'BugHunterLevel2') badges.push('<:discord_bughunterlvl2:1109431798494134282>')
            if (badge === 'ActiveDeveloper') badges.push('<:discord_activedeveloperbadge:1109431903758581870>')
            if (badge === 'VerifiedDeveloper') badges.push('<:discord_verifiedbotdeveloper:1109432005327859783>')
            if (badge === 'PremiumEarlySupporter') badges.push('<:discord_nitroearlysupporter:1109432129630240798>')

            if (badge === 'Spammer') {
                badges.push('<:spammer:1109434433255251968>')
                extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371746622119976/spammer.png')
            }

            if (badge === 'TeamPseudoUser') {
                badges.push('<:zenith_botdeveloper:1109437531038167080>')
                extrabadges.push('https://media.discordapp.net/attachments/1082188213071909014/1110906772618743818/zenit_botdeveloper.png?width=160&height=160')
            }
           
        }))

        const userData = await fetch(`https://japi.rest/discord/v1/user/${user.id}`);
        const { data } = await userData.json();

        if (data.public_flags_array) {
 
            await Promise.all(data.public_flags_array.map(async badge => {
 
                if (badge === 'NITRO') badges.push('<:nitro:1109437857858326610>')
 
            }))
        }

        if (user.bot) {

            const botFetch = await fetch(
                `https://discord.com/api/v10/applications/${user.id}/rpc`
            );
          
            let json = await botFetch.json();
            let flagsBot = json.flags;

            const gateways = {
                APPLICATION_COMMAND_BADGE: 1 << 23,
            };
          
            const arrayFlags = [];

            for (let i in gateways) {
                const bit = gateways[i];
                if ((flagsBot & bit) === bit) arrayFlags.push(i);
            }

            if (arrayFlags.includes('APPLICATION_COMMAND_BADGE')) {
                badges.push('<:slash_commandbot:1110906957767921776>')
            }

        }

        if (member.premiumSinceTimestamp) {

            let claimed = '';

            if (member.premiumSinceTimestamp + 2629800000 * 24 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl9:1109438108346368140>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371051269439568/nitroboost9.png')
                    claimed = 'yes'
                }
                
            }

            if (member.premiumSinceTimestamp + 2629800000 * 15 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl8:1109438252064190574>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371050938081280/nitroboost8.png')
                    claimed = 'yes'
                }
 
            }

            if (member.premiumSinceTimestamp + 2629800000 * 15 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl7:1109438340375265360>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371053249134612/nitroboost7.png')
                    claimed = 'yes'
                }

            }

            if (member.premiumSinceTimestamp + 2629800000 * 12 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl6:1109438518008229978>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371052615811152/nitroboost6.png')
                    claimed = 'yes'
                }

            }

            if (member.premiumSinceTimestamp + 2629800000 * 9 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl5:1109438591534383235>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371052376727663/nitroboost5.png')
                    claimed = 'yes'
                }

            }

            if (member.premiumSinceTimestamp + 2629800000 * 6 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl4:1109438667690348615>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371052095701053/nitroboost4.png')
                    claimed = 'yes'
                }
 
            }

            if (member.premiumSinceTimestamp + 2629800000 * 3 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl3:1109438754290151525>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371051877613578/nitroboost3.png')
                    claimed = 'yes'
                }
 
            }

            if (member.premiumSinceTimestamp + 2629800000 * 2 < Date.now()) {

                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl2:1109439075917766716>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371053022650408/nitroboost2.png')
                    claimed = 'yes'
                }
  
            }

            if (member.premiumSinceTimestamp + 2629800000 * 2 > Date.now()) {
                
                if (!claimed || claimed === '') {
                    badges.push('<:nitroboostlvl1:1109439141772533770>')
                    extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109371051613356092/nitroboost1.png')
                    claimed = 'yes'
                }
                
            }

        }

        if (!user.discriminator || user.discriminator === 0 || user.tag === `${user.username}#0`) {
            badges.push('<:knownas:1110907383959539732>')
            extrabadges.push('https://cdn.discordapp.com/attachments/1080219392337522718/1109461965711089694/username.png')
        }
    
        const embed = new EmbedBuilder()
        .setColor("#E0E7B5")
        .setAuthor({ name: tag, iconURL: icon})
        .setTitle(`${user.username}'s Infomation`)
        .setThumbnail(icon)
        .addFields({ name: "Username", value: `> ${user} (${user.tag})`, inline: false})
        .addFields({ name: "User ID:", value:`> ${user.id}`, inline: false })
        .addFields({ name: "Badges", value: `> ${badges.join(' ') || '**The user doesn\'t have any badges!**'}`, inline: false })
        .addFields({ name: "Roles", value: `> ${roles.join(' ')}`, inline: false})
        .setImage('attachment://user-info.png')
        .setTimestamp()

        if (data.bio) {
            embed.addFields({ name: `User Description`, value: `${data.bio}`})
        }

        if (member.premiumSinceTimestamp) {
            embed.addFields({ name: "Booster Since", value: `> <t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>`, inline: true })
            embed.addFields({ name: "Joined Server", value: `> <t:${parseInt(member.joinedAt / 1000)}:R>`, inline: true})
            embed.addFields({ name: "Joined Discord", value: `> <t:${parseInt(user.createdAt / 1000)}:R>`, inline: true})
        } else {
            embed.addFields({ name: "Joined Server", value: `> <t:${parseInt(member.joinedAt / 1000)}:R>`, inline: true})
            embed.addFields({ name: "Joined Discord", value: `> <t:${parseInt(user.createdAt / 1000)}:R>`, inline: true})
        }

        if (extrabadges) {
            const profileBuffer = await profileImage(member.id, { customBadges: extrabadges });
            const attachment = new AttachmentBuilder(profileBuffer, { name: 'user-info.png' })
            await interaction.editReply({ embeds: [embed], files: [attachment] });
        } else {
            const profileBuffer = await profileImage(member.id);
            const attachment = new AttachmentBuilder(profileBuffer, { name: 'user-info.png' })
            await interaction.editReply({ embeds: [embed], files: [attachment] });
        }

    }
}