const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { performance } = require('perf_hooks');
const os = require('os');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription(`Shows Zenith's Ping's information.`),

    async execute(interaction, client) {

        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setLabel('Support Server')
            .setStyle(ButtonStyle.Link)
            .setURL("https://discord.gg/CSYjWb7tzs"),

            new ButtonBuilder()
            .setLabel('Vote Me')
            .setStyle(ButtonStyle.Link)
            .setURL("https://top.gg/bot/1096048779641237635/vote"),

            new ButtonBuilder()
            .setLabel('Bot Invite')
            .setStyle(ButtonStyle.Link)
            .setURL("https://discord.com/api/oauth2/authorize?client_id=1076798263098880116&permissions=137439292488&scope=bot%20applications.commands")
        )


        const embedping = new EmbedBuilder()
        .setColor("#D8D4FF")
        .setTitle('Connection between Zenith and your client')
        .setDescription( `**Pong**: \`${Math.round(client.ws.ping)}ms\``)
        .addFields({ name: "Command Status", value: "<a:Online:1115100737073070182> 145 Commands Are Onlined!", inline: true})
        .addFields({ name: "Database Status", value: "<a:Online:1115100737073070182> My database is Onlined!", inline: true})
        .addFields({ name: "Developer Command Status", value: "<a:Online:1115100737073070182> 4 Commands Are Onlined!", inline: true})
        .setTimestamp()

        await interaction.reply({ embeds: [embedping] })

        }
    }
