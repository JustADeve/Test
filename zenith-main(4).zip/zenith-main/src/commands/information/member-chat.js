const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const Discord = require('discord.js');
const QuickChart = require('quickchart-js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('membercount-chart')
        .setDescription('Shows the number of members on the server.'),
    async execute(interaction) {
        const guild = interaction.guild;
        const totalMembers = guild.memberCount;
        const botMembers = guild.members.cache.filter(member => member.user.bot).size;
        const humanMembers = totalMembers - botMembers;
        const last24Hours = guild.members.cache.filter(member => Date.now() - member.joinedTimestamp < 24 * 60 * 60 * 1000).size;
        const last7Days = guild.members.cache.filter(member => Date.now() - member.joinedTimestamp < 7 * 24 * 60 * 60 * 1000).size;
       


        const chart = new QuickChart();
        chart
            .setConfig({
                type: 'bar',
                data: {
                    labels: ['Total', 'Members', 'Bots', '24h', '7 days'],
                    datasets: [{
                        label: 'Member Count',
                        data: [totalMembers, humanMembers, botMembers, last24Hours, last7Days],
                        backgroundColor: ['#36a2eb', '#ffce56', '#ff6384', '#cc65fe', '#66ff99']
                    }]
                },
  options: {
                    plugins: {
                        backgroundImageUrl: 'https://media.discordapp.net/attachments/1100630245914202112/1114228226005405797/black-texture-wallpaper-preview.jpg?width=910&height=568',// YOur link
                        title: {
                            display: true,
                            text: `Server Member ${guild.name}`
                        }
                    }
                },



            
            })

            .setWidth(500)
            .setHeight(300)
            .setBackgroundColor('#151515');
           


        const chartUrl = await chart.getShortUrl();

        const embed = new EmbedBuilder()

            .setTitle(`${guild.name} Server's Member Information`)
            .setColor('#ae7424')
            .setFooter({ text: `Zenith`, iconURL: "https://media.discordapp.net/attachments/1100630245914202112/1113480548527112302/NitrixEXE_27.png?width=640&height=640"})
            .setDescription(`Total Members: **${totalMembers}**\nHuman Members: **${humanMembers}**\nBots: **${botMembers}**\nJoined This Server Last 24h: **${last24Hours}**\nJoined This Server Last 7 days: **${last7Days}**`)
            .setImage(chartUrl);

        await interaction.reply({ embeds: [embed] });
    },
};