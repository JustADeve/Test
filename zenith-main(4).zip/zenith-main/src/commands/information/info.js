const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder } = require('discord.js');
const { performance } = require('perf_hooks');
const os = require('os');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription(`Shows Zenith's information.`),
    async execute(interaction, client) {

        let servercount = await client.guilds.cache.reduce((a,b) => a+b.memberCount, 0);

        // Get Mongoose ping
        const dbPingStart = Date.now();
        const dbPing = Date.now() - dbPingStart;
       let totalSeconds = (client.uptime / 1000);
       let days = Math.floor(totalSeconds / 86400);
       totalSeconds %= 86400;
       let hours = Math.floor (totalSeconds / 3600);
       totalSeconds %=3600;
       let minutes = Math.floor(totalSeconds / 60);
       let seconds = Math.floor(totalSeconds % 60);


        let uptime = `${days} days,  ${hours} hours, ${minutes} minutes, ${seconds} seconds`;

        const usage2 = process.memoryUsage();
        const usage = process.cpuUsage();
        const usagePercent = usage.system / usage.user * 100;
        const usagePercent2 = usage2.system / usage2.user * 100;
        const memoryUsed = (os.totalmem - os.freemem)/1000000000
        const memoryTotal = os.totalmem()/1000000000
        const specsembed = new EmbedBuilder()
        const embed = new EmbedBuilder()
        .setColor("#D8D4FF")
        .setTitle(`Zenith Bot's Information`)
        .setTimestamp()
        .setThumbnail('https://media.discordapp.net/attachments/1115102010170167356/1124338129566978138/NitrixEXE_27.png?width=640&height=640')
        .addFields({ name: "Basic Info", value: `> **Developer:** \`Zenith#3312 [751708824796266558]\` \n> **Server Count:** ${client.guilds.cache.size}\n> **User Count:** 50,000\n> **Total Command:** 145 || ${client.commands.size} (4 Command For Developer)`})
        .addFields({ name: "Status", value: `> **Ping:** \`${Math.round(client.ws.ping)} ms\`\n> **Uptime:** ${uptime}\n> **OS:** ${os.type} (${os.release})\n> **CPU Usage:** ${usagePercent.toFixed(1)}% (${os.arch})\n> **Memory:** ${(memoryUsed/memoryTotal * 100).toFixed(1)}%`})

        await interaction.reply({ embeds: [embed] })
}
}
