const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('vote')
    .setDescription('Vote for Zenith on Top.gg!'),

    async execute (interaction) {
        const embed = new EmbedBuilder()
        .setTitle('Vote For Me!')
        .setColor("#CFC5F6")
        .setFooter({ text: `Thanks For Voting To Me`})
        .setDescription('> By pressing the button bellow you can help our bot grow on **Top.gg** by voting for it!')
        .setTimestamp()
        .setImage('https://media.discordapp.net/attachments/1115102010170167356/1124339749310701599/sa.jpg?width=1335&height=701')

        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setLabel('Vote')
            .setStyle(ButtonStyle.Link)
            .setURL('https://top.gg/bot/1096048779641237635/vote')
        )

        await interaction.reply({ embeds: [embed], components: [button] });
    }
}