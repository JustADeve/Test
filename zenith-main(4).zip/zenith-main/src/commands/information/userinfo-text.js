
const { AttachmentBuilder, ContextMenuInteraction, EmbedBuilder, ContextMenuCommandBuilder, ApplicationCommandType,} = require("discord.js");
const { profileImage } = require("discord-arts");

module.exports = {
    data: new ContextMenuCommandBuilder()
        .setName("User-Info")
        .setType(ApplicationCommandType.User)
        .setDMPermission(false),
    /**
     * 
     * @param {ContextMenuInteraction} interaction 
     */
    async execute(interaction) {
        await interaction.deferReply()
        let user = interaction.options.getUser('user') || interaction.user;
        let member = await interaction.guild.members.cache.get(user.id)
       const icon = user.displayAvatarURL();
        const tag = user.tag;  
        let flags = user.flags.toArray();

        if (member.user.bot) return interaction.editReply({
            embeds:
                [
                    new EmbedBuilder().setDescription("<:yellow_warning:1115100685252431962> At this moment, bots are not supported for this command.").setColor("Yellow")
                ],
            ephemeral: true
        })

        try {
            const fetchedMember = await interaction.guild.members.fetch();

            const profileBuffer = await profileImage(member.id);
            const imageAttachment = new AttachmentBuilder(profileBuffer, { name: "profile.png" });

            const joinPosition = Array.from(fetchedMember
                .sort((a, b) => a.joinedTimestamp - b.joinedTimestamp)
                .keys())
                .indexOf(member.id) + 1;

            const topRoles = member.roles.cache
                .sort((a, b) => b.position - a.position)
                .map(role => role)
                .slice(0, 3);

            const userBadges = member.user.flags.toArray()

            const joinTime = parseInt(member.joinedTimestamp / 1000);
            const createdTime = parseInt(member.user.createdTimestamp / 1000);

            const Booster = member.premiumSince ? "<:nitroboostlvl7:1109438340375265360>" : "The user didn't boost this server!";

            const Embed = new EmbedBuilder()
                .setAuthor({ name: `${member.user.tag} Information`, iconURL: member.displayAvatarURL() })
                .setColor(member.displayColor)
                .setDescription(`On <t:${joinTime}:D>, ${member.user.username} joined as the **${addSuffix(joinPosition)}** member of this server.`)
                .setImage("attachment://profile.png")
                .addFields([
                    { name: "Username", value: `> ${user} (${user.tag})`, inline: false},
                    { name: "UserID", value: `${member.id}`, inline: false},
                    { name: "Booster", value: `${Booster}`, inline: false },
                    { name: "Top Roles", value: `${topRoles.join("").replace(`<@${interaction.guildId}>`)}`, inline: false },
                    { name: "Created", value: `<t:${createdTime}:R>`, inline: true },
                    { name: "Joined", value: `<t:${joinTime}:R>`, inline: true },
                    { name: "Badges", value: `${addBadges(userBadges).join("")}`, inline: false },
                    { name: "Avatar", value: `[Link](${member.displayAvatarURL()})`, inline: true },
                    { name: "Banner", value: `[Link](${(await member.user.fetch()).bannerURL()})`, inline: true },
                ])
                .setTimestamp();

            interaction.editReply({ embeds: [Embed], files: [imageAttachment] })
        } catch (error) {
            interaction.editReply({
                embeds:
                    [
                        new EmbedBuilder().setDescription("<:yellow_warning:1115100685252431962> Something went wrong. Please contact the developer. If this keep repeating, you can contact the developer by joining this server [here](https://discord.gg/HsGjWRd7cw)").setColor("Yellow")
                    ],
                ephemeral: true
            });
            throw error;
        }
    }
}

function addSuffix(number) {
    if (number % 100 >= 11 && number % 100 <= 13)
        return number + "th"

    switch (number % 10) {
        case 1: return number + "st";
        case 2: return number + "nd";
        case 3: return number + "rd";
    }
    return number + "th";
}

function addBadges(badgeNames) {
    if (!badgeNames.length) return ["X"];
    const badgeMap = {
        "ActiveDeveloper": "<:discord_activedeveloperbadge:1109431903758581870>",
        "BugHunterLevel1": "<:discord_bughunterlvl1:1109431699672141935>",
        "BugHunterLevel2": "<:discord_bughunterlvl2:1109431798494134282>",
        "PremiumEarlySupporter": "<:discord_nitroearlysupporter:1109432129630240798>",
        "Partner": "<:discord_partner:1115100727132569784>",
        "Staff": "<:discord_staff:1115110436858232853>",
        "HypeSquadOnlineHouse1": "<:discord_bravery:1115110790727467008>", // bravery
        "HypeSquadOnlineHouse2": "<:discord_brilliance:1115100720312619008>", // brilliance
        "HypeSquadOnlineHouse3": "<:discord_balance:1115100731859554314>", // balance
        "Hypesquad": "<:discord_hypesquad:1115100723567411310>",
        "CertifiedModerator": "<:discord_moderator:1115100729372311582>",
        "VerifiedDeveloper": "<:discord_verifiedbotdeveloper:1109432005327859783>",
    };

    return badgeNames.map(badgeName => badgeMap[badgeName] || '❔');
}