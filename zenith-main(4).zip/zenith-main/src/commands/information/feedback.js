const {  SlashCommandBuilder,  EmbedBuilder,  PermissionsBitField,  ChannelType,  ModalBuilder,  TextInputBuilder,TextInputStyle,  ActionRowBuilder} = require("discord.js");
const { request } = require("https");
  
  module.exports = {
    data: new SlashCommandBuilder()
      .setName("feedback")
      .setDescription("Feedback our Zenith Bot"),
    async execute(interaction) {
  
          const modal = new ModalBuilder()
            .setTitle("feedback")
            .setCustomId("modal");

          const name = new TextInputBuilder()
            .setCustomId("name")
            .setRequired(true)
            .setLabel(`Provide me your Discord Name + Discord Tag`)
            .setPlaceholder("Eg: Zenith#3312 (751708824796266558)")
            .setStyle(TextInputStyle.Paragraph);

            const mark = new TextInputBuilder()
            .setCustomId("mark")
            .setRequired(true)
            .setLabel(`Out of 10, how many you will give to Zenith`)
            .setPlaceholder("Eg: 10/10 or 8/10")
            .setStyle(TextInputStyle.Short);

            const feedbackfeeling = new TextInputBuilder()
            .setCustomId("feedbackfeeling")
            .setRequired(true)
            .setLabel(`Provide us what do you think about Zenith`)
            .setPlaceholder("Your feeling that using Zenith (try to be positive)")
            .setStyle(TextInputStyle.Paragraph);

            const problem = new TextInputBuilder()
            .setCustomId("problem")
            .setRequired(true)
            .setLabel(`Problem when using Zenith`)
            .setPlaceholder("Your problem that using Zenith (try to be all the problems)")
            .setStyle(TextInputStyle.Paragraph);

  
          const firstActionRow = new ActionRowBuilder().addComponents(name);
          const secondActionRow = new ActionRowBuilder().addComponents(mark);
          const thirdActionRow = new ActionRowBuilder().addComponents(feedbackfeeling);
          const fourthActionRow = new ActionRowBuilder().addComponents(problem);

  
          modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow  );
  
          interaction.showModal(modal);
        }
    };