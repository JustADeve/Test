const { SlashCommandBuilder, StringSelectMenuBuilder, PermissionsBitField, ButtonStyle, ButtonBuilder, EmbedBuilder, ActionRowBuilder } = require('discord.js');
var timeout = [];

module.exports = {
    data: new SlashCommandBuilder()
    .setName('bot')
    .setDescription('Cannot find what you were wishing to? Check this out!')
    .addSubcommand(command => command.setName('invite').setDescription('Join our official support server for Zenith!'))
    .addSubcommand(command => command.setName('help').setDescription('Get some information on our bot commands and plans.')),
    async execute(interaction, client) {

        const sub = interaction.options.getSubcommand();

        switch (sub) {
            case 'invite':

            const button = new ActionRowBuilder()
            .addComponents(
            new ButtonBuilder()
            .setLabel('Support Server')
            .setStyle(ButtonStyle.Link)
            .setURL("https://discord.gg/HsGjWRd7cw"),
           
            new ButtonBuilder()
            .setLabel('Vote Me')
            .setStyle(ButtonStyle.Link)
            .setURL("https://top.gg/bot/1096048779641237635/vote"),

            new ButtonBuilder()
            .setLabel('Bot Invite')
            .setStyle(ButtonStyle.Link)
            .setURL("https://discord.com/api/oauth2/authorize?client_id=1096048779641237635&permissions=68165425426423&scope=applications.commands%20bot")
        )

            const embedhelpserver = new EmbedBuilder()
            .setColor("#B7E5D5")
            .setTitle('Join our support server for further help!')
            .setTimestamp()
            .setThumbnail('https://media.discordapp.net/attachments/1115102010170167356/1124338129566978138/NitrixEXE_27.png?width=640&height=640')
            .addFields({ name: `Support Server`, value: `[Click here](https://discord.gg/HsGjWRd7cw) To Join Our Support Server.`, inline: true})
            .addFields({ name: `Vote Me`, value: `[Click here](https://top.gg/bot/1096048779641237635/vote) To Vote me on top.gg`, inline: true})
            .addFields({ name: `Invite Me`, value: `[Click here](https://discord.com/api/oauth2/authorize?client_id=1096048779641237635&permissions=68165425426423&scope=applications.commands%20bot) To Invite Me To Your Server.`, inline: true})

        
            await interaction.reply({ embeds: [embedhelpserver], components: [button] })

            break;
            case 'help':

            const helprow1 = new ActionRowBuilder()
            .addComponents(

            new StringSelectMenuBuilder()
            .setMinValues(1)
            .setMaxValues(1)
            .setCustomId('selecthelp')
            .setPlaceholder('Select a menu')
            .addOptions(
                {
                    label: 'Recently Updates',
                    description: 'Get to know Zenith Recently Updates',
                    emoji: '<:news:1115100706798567424>',
                    value: 'updates',
                },

                {
                    label: 'Security Command',
                    description: 'Displays Zenith\'s security commands',
                    emoji: '<:security:1115100721340227584>',
                    value: 'security'
                },

                {
                    label: 'Economy Command',
                    description: 'Displays Zenith\'s economy commands',
                    emoji: '<:economy:1115100682391912538>',
                    value: 'economy'
                },

                {
                    label: 'Information Command',
                    description: 'Displays Zenith\'s Information commands',
                    emoji: '<:information:1115100697243955302>',
                    value: 'information',
                },

                {
                    label: 'Leveling Command',
                    description: 'Displays Zenith\'s Leveling commands',
                    emoji: '<:Ranking:1115100694161133618>',
                    value: 'leveling',
                },

                {
                    label: 'Misc Command',
                    description: 'Displays Zenith\'s Misc commands',
                    emoji: '<:gamer:1115100738033565770>',
                    value: 'misc',
                },

                {
                    label: 'Minigame Command',
                    description: 'Displays Zenith\'s Misc commands',
                    emoji: '<:minigames:1115100688930832455>',
                    value: 'game',
                },

                {
                    label: 'Moderation Command',
                    description: 'Displays Zenith\'s Moderation commands',
                    emoji: '<:automod:1115100735751856219>',
                    value: 'moderation',
                },

                {
                    label: 'Music Command',
                    description: 'Displays Zenith\'s Music commands',
                    emoji: '<:song:1115100696048574584>',
                    value: 'music',
                },
                {
                    label: 'Utility Command',
                    description: 'Displays Zenith\'s Utility/Settings commands',
                    emoji: '<:settings:1115100699307560980>',
                    value: 'utility',
                },

                {
                    label: 'Setting Command',
                    description: 'Displays Zenith\'s Utility/Settings commands',
                    emoji: '<:D_Setting:1115100713798864917>',
                    value: 'setting',
                },

                {
                    label: 'Giveaway Command',
                    description: 'Displays Zenith\'s Giveaway commands',
                    emoji: '<:giveaway_icon:1115100718311948338>',
                    value: 'giveaway',
                },
            ),
        );

        const embed = new EmbedBuilder()
        .setColor("#96A9FF")
        .setAuthor({ name: `Zenith Help Menu` })
        .setFooter({ text: `Thanks for using Zenith`})
        .setThumbnail('https://media.discordapp.net/attachments/1115102010170167356/1124338129566978138/NitrixEXE_27.png?width=640&height=640')
        .setDescription("Zenith, an multipurpose discord bot that can help your server on moderation and more.\n\n We have our own AI command, which is </ask-gpt:1100374089564164187>, using GPT Version 3. There's alot more AI command rolling out so keep in touch with us\n\n <:automod:1115100735751856219> **__Popular/Recommended Features:__**\n<:reply3:1115100739329601609> AutoMod System\n<:reply2:1115100712486056006> Radio Station\n<:reply2:1115100712486056006> Modmail system (like ticket system)\n<:reply2:1115100712486056006> AFK System\n<:reply2:1115100712486056006> ModLog system\n<:replyL:1115100715002634240> **And Much More....**\n\n<:yeye:1115100704470749274> **__Information:__**\n<:reply3:1115100739329601609> Used By 10,000+ members\n<:reply2:1115100712486056006> Trusted in 70+ Guilds\n<:replyL:1115100715002634240> Trusted By **RYZVISION** and **Raiden Community**\n\n <:links:1115100707931029544> **__Zenith's Links:__**\n> **[Invite Zenith Now](https://discord.com/api/oauth2/authorize?client_id=1096048779641237635&permissions=68165425426423&scope=applications.commands%20bot)**\n> **[Join Zenith Community](https://discord.gg/HsGjWRd7cw)**\n> **[Vote For Zenith](https://top.gg/bot/1096048779641237635/vote)**")
        .setTimestamp()

        await interaction.reply({ embeds: [embed], components: [helprow1] });


                }
            } 
        }
