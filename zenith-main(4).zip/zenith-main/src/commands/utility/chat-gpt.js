const {SlashCommandBuilder, EmbedBuilder} = require('discord.js');
const { Configuration, OpenAIApi} = require('openai');

const configuration = new Configuration({
    apiKey: ''
});

const openai = new OpenAIApi(configuration);

module.exports = {
    data: new SlashCommandBuilder()
    .setName('ask-gpt')
    .setDescription("Ask chat-gpt the question that u wanna ask")
    .addStringOption(option => option.setName('question').setDescription('the question that u wanna ask chat-gpt').setRequired(true)),
    async execute (interaction) {

        await interaction.deferReply();

        const question = interaction.options.getString('question');

        try {
            const res = await openai.createCompletion({
                model: 'text-davinci-003',
                max_tokens: 2048,
                temperature: 0.5,
                prompt: question
            })

            const embed = new EmbedBuilder()
            .setColor('#2f3136')
            .setTitle(`Question: ${question}`)
            .setThumbnail('https://media.discordapp.net/attachments/1083369585161551882/1124272013310185493/gpt2.png?width=701&height=701')
            .setTimestamp()
            .setFooter({ text: "GPT Version 3" })
            .setDescription(`${res.data.choices[0].text}`)

            await interaction.editReply({ embeds: [embed] });
        } catch(e) {
            return await interaction.editReply({ content: `<:yellow_warning:1115100685252431962> Request failed with status code **${e.response.status}**`, ephemeral: true})
        }
    }
}
