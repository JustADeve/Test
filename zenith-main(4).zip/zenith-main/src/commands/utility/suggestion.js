const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require('discord.js');
const pollschema = require('../../Schemas.js/votes');
 
module.exports = {
    data: new SlashCommandBuilder()
    .setName('suggestion-send')
    .setDescription('send a suggestion')
    .addStringOption(option => option.setName('topic').setDescription('your topic').setRequired(true).setMinLength(1).setMaxLength(2000)),
    async execute(interaction) {
 
        await interaction.reply({ content: `Your suggestion has began!`, ephemeral: true})
        const topic = await interaction.options.getString('topic')
 
        const embed = new EmbedBuilder()
        .setColor("#ecb6d3")
        .setTimestamp()
        .setThumbnail('https://media.discordapp.net/attachments/1115102010170167356/1115265524973191179/1086406856513167450.png?width=160&height=160')
        .setTitle('New Suggestion Have Arrived ')
        .setDescription(`> ${topic}`)
        .addFields({ name: `Upvotes`, value: `> **No votes**`, inline: true})
        .addFields({ name: `Downvotes`, value: `> **No votes**`, inline: true})
        .addFields({ name: `Original Author`, value: `> ${interaction.user}`})
 
        const buttons = new ActionRowBuilder()
        .addComponents(
 
        new ButtonBuilder()
        .setCustomId('up')
        .setLabel(' ')
        .setEmoji('<:green_thumb_up:1115100692961574912>')
        .setStyle(ButtonStyle.Secondary),
 
        new ButtonBuilder()
        .setCustomId('down')
        .setLabel(' ')
        .setEmoji('<:red_thumb_down:1115100724532084808>')
        .setStyle(ButtonStyle.Secondary),
 
        new ButtonBuilder()
        .setCustomId('votes')
        .setLabel('Who Voted?')
        .setStyle(ButtonStyle.Secondary)
        )
 
        const msg = await interaction.channel.send({ embeds: [embed], components: [buttons] });
        msg.createMessageComponentCollector();
 
        await pollschema.create({
            Msg: msg.id,
            Upvote: 0,
            Downvote: 0,
            UpMembers: [],
            DownMembers: [],
            Guild: interaction.guild.id,
            Owner: interaction.user.id
        })
    }
}