const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('say')
    .setDMPermission(false)
    .addStringOption(option => option.setName('message').setDescription('Message provided will be sent by Zenith').setRequired(true).setMaxLength(2000).setMinLength(1))
    .setDescription('Say something for Zenith.'), 
    async execute(interaction, client) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages) && interaction.user.id !== '751708824796266558') return await interaction.reply({ content: 'You **do not** have the permission to do that!', ephemeral: true});

        const message = interaction.options.getString('message')

        await interaction.channel.send({ content: `${message}` })
        await interaction.reply({ content: `<:green_check:1115100686682706042> Message "**${message}**" has been **sent** as me!`, ephemeral: true})
    }
}
