const { SlashCommandBuilder } = require('discord.js');
const AutoDelete = require('../../Schemas.js/AutoDeleteSchema');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('auto-delete')
    .setDescription('Automatically deletes messages from a specified channel.')
    .addSubcommand(subcommand =>
      subcommand
        .setName('setup')
        .setDescription('Sets up the auto-delete system.')
        .addChannelOption(option =>
          option.setName('channel')
            .setDescription('The channel to monitor for message deletion')
            .setRequired(true)
        )
        .addIntegerOption(option =>
          option.setName('time')
            .setDescription('The time interval in minutes')
            .setRequired(true)
        )
        .addBooleanOption(option =>
          option.setName('user-option')
            .setDescription('Whether to exclude the user\'s own messages')
            .setRequired(false)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('disable')
        .setDescription('Disables the auto-delete system.')
    ),
  async execute(interaction) {
    // Check if the user is an admin
    if (!interaction.member.permissions.has('ADMINISTRATOR')) {
      return await interaction.reply('You must be an administrator to use this command.');
    }

    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'setup') {
      const userOption = interaction.options.getBoolean('user-option') ?? false;
      const channel = interaction.options.getChannel('channel');
      const time = interaction.options.getInteger('time');

      try {
        const existingSetup = await AutoDelete.findOne({ guildId: interaction.guild.id });
        if (existingSetup) {
          return await interaction.reply('Auto-delete system is already set up for this guild.');
        }

        const newSetup = new AutoDelete({
          guildId: interaction.guild.id,
          channelId: channel.id,
          userOption: userOption,
          timeInterval: time,
        });

        await newSetup.save();
        await interaction.reply('Auto-delete system has been set up.');
      } catch (error) {
        console.error('Error setting up auto-delete:', error);
        await interaction.reply('An error occurred while setting up auto-delete system.');
      }
    } else if (subcommand === 'disable') {
      try {
        await AutoDelete.deleteOne({ guildId: interaction.guild.id });
        await interaction.reply('Auto-delete system has been disabled.');
      } catch (error) {
        console.error('Error disabling auto-delete:', error);
        await interaction.reply('An error occurred while disabling auto-delete system.');
      }
    }
  },
};
