const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const translate = require("@iamtraction/google-translate");
 
module.exports = {
    data: new SlashCommandBuilder()
    .setName('translate')
    .setDescription('Translator')
    .addSubcommand(command => command.setName('text').setDescription('This will translate text for you')
    .addStringOption(option => option.setName('message').setDescription('What do you want to translate?').setRequired(true))
    .addStringOption(option => option.setName('language').setDescription('What language do you want to translate to?').addChoices(
        { name: "English", value: "en" },
        { name: "Latin", value: "la" },
        { name: "French", value: "fr" },
        { name: "German", value: "de" },
        { name: "Italian", value: "it" },
        { name: "Portuguese", value: "pt" },
        { name: "Spanish", value: "es" },
        { name: "Hindi", value: "hi" },
        { name: "Russian", value: "ru" },
        { name: "Japanese", value: "ja" },
        { name: "Arabic", value: "ar" },
        { name: "Chinese Simplified", value: "zh-cn" },
        { name: "Korean", value: "ko" },
        { name: "Malay", value: "ms" },
    ).setRequired(true))),
    async execute (interaction) {
        const sub = interaction.options.getSubcommand();
        switch (sub) {
            case 'text':
                const text = interaction.options.getString(`message`);
                const lan = interaction.options.getString(`language`);
 
                const translated = await translate(text, { to: `${lan}` });
 
                const embed = new EmbedBuilder()
                .setTitle(`<:translate:1115100730634817547> Successfully Translated!`)
                .setColor('#2f3136')
                .addFields({ name: `Original Message: `, value: `\`\`\` ${text}\`\`\``, inline: false })
                .addFields({ name: `Translated Message: `, value: `\`\`\` ${translated.text}\`\`\``, inline: false })
 
                await interaction.reply({ embeds: [embed]});
        }
    }
}