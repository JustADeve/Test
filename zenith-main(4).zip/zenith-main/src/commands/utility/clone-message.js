const {
    ContextMenuInteraction,
    EmbedBuilder,
    ContextMenuCommandBuilder,
    ApplicationCommandType,
    PermissionsBitField
} = require("discord.js");

module.exports = {
    data: new ContextMenuCommandBuilder()
        .setName("Clone Message")        
        .setType(ApplicationCommandType.Message)
        .setDMPermission(false),
    /**
     * 
     * @param {ContextMenuInteraction} interaction 
     */
    async execute(interaction) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages) && interaction.user.id !== '751708824796266558') return await interaction.reply({ content: 'You **do not** have the permission to do that!', ephemeral: true});
        await interaction.deferReply({ ephemeral: true });

        const message = await interaction.channel.messages.fetch(interaction.targetId);
        
        if (message.content && message.content !== '') {

            if (message.attachments.size > 0) {

                const attachment = `${message.attachments.first()?.url}`;
                if (message.embeds) {
                    await interaction.channel.send({ content: `${message.content} \n\n${attachment}`, embeds: message.embeds })
                } else {
                    await interaction.channel.send({ content: `${message.content} \n\n${attachment}` })
                }

            } else {

                if (message.embeds) {
                    await interaction.channel.send({ content: `${message.content}`, embeds: message.embeds })
                } else {
                    await interaction.channel.send({ content: `${message.content}` })
                }

            }

        } else {

            if (message.attachments.size > 0) {

                const attachment = `${message.attachments.first()?.url}`;
                if (message.embeds) {
                    await interaction.channel.send({ content: `${attachment}`, embeds: message.embeds })
                } else {
                    await interaction.channel.send({ content: `${attachment}` })
                }

            } else {

                if (message.embeds) {

                    try {
                        await interaction.channel.send({ embeds: message.embeds })
                    } catch {
                        return await interaction.editReply({ content: `I **couldn't** clone that message!`, ephemeral: true })
                    }
                    
                } else {
                    return await interaction.editReply({ content: `I **couldn't** clone that message!`, ephemeral: true })
                }

            }

        }

        await interaction.editReply({ content: `**Successfully** cloned your **message**!`})
        
    }
}