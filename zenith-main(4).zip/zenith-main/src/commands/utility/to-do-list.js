const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const todoSchema = require("../../Schemas.js/todo");

module.exports = {
    moderatorOnly: true,
    data: new SlashCommandBuilder()
        .setName("to-do")
        .setDescription("Manage your to-do list!")
        .setDMPermission(false)
        .addSubcommand(subcommand =>
            subcommand.setName("add")
                .setDescription("Add a task to your to-do list")
                .addStringOption(option =>
                    option.setName("task")
                        .setDescription("The task to add")
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand.setName("list")
                .setDescription("Check your to-do list")
        )
        .addSubcommand(subcommand =>
            subcommand.setName("check")
                .setDescription("Check off a task from your to-do list")
                .addIntegerOption(option =>
                    option.setName("number")
                        .setDescription("The task number that you finished")
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand.setName("clear")
                .setDescription("Clear all your tasks from your to-do list")
        ),

    async execute(interaction) {
        const { options, guildId, user, member } = interaction;

        const sub = options.getSubcommand(["add", "list", "check", "clear"]);
        const task = options.getString("task")
        const taskId = options.getInteger("number") - 1;
        const taskDate = new Date(interaction.createdTimestamp).toLocaleDateString();


        switch (sub) {
            case "add":

                todoSchema.findOne({ GuildID: guildId, UserID: interaction.member.id }, async (err, data) => {
                    if (err) throw err;

                    if (!data) {
                        data = new todoSchema({
                            GuildID: guildId,
                            UserID: interaction.member.id,
                            Content: [
                                {
                                    Task: task,
                                    Date: taskDate
                                }
                            ],
                        });
                    } else {
                        const taskContent = {
                            Task: task,
                            Date: taskDate
                        }
                        data.Content.push(taskContent);
                    }
                    data.save();

                        try {
                            const loadembeds = new EmbedBuilder()
                        .setDescription(`<a:loading:1115100728122417223> Adding **${task}** to your to-do list...`)
                        .setColor("#ffd870")

                        await interaction.reply({ embeds: [loadembeds] })
                           
                        const asdfembed = new EmbedBuilder()
                        .setColor("#ffd870")
                            .setDescription(`<:green_check:1115100686682706042> Success! **${task}** was added to your to-do list!`)
                            .setTimestamp()

                        interaction.editReply({ embeds: [asdfembed] });
                    } catch (err) {
                        console.log(err)
                    }
                });

                break;
            case "list":
                
                todoSchema.findOne({ GuildID: guildId, UserID: interaction.member.id }, async (err, data) => {
                    if (err) throw err;
                    
                    if (data) {
                        const loadembeds = new EmbedBuilder()
                        .setDescription(`<a:loading:1115100728122417223> Fetching your to-do list...`)
                        .setColor("#ffd870")

                        await interaction.reply({ embeds: [loadembeds] })
                        if (data.Content.length === 0) {

                            const embedr = new EmbedBuilder()
                            .setColor("#ffd870")
                                .setDescription(`<:red_cancel:1115100681129431060> You **don't have** a to-do list, use \`/to-do add\` to add a to-do reminder for you`)
    
                           await interaction.editReply({ embeds: [embedr] });
                            } else {
                                const nembed = new EmbedBuilder()
                        .setColor("#ffd870")
                        .setTitle(`Here's your to-do list!`)
                            .setDescription(`${data.Content.map(
                                (w, i) =>
                                    `**Task ${i + 1}:**
                                   > **${w.Task}**
                           > *Date Added: ${w.Date}*\n\n
                            `
                            ).join(" ")}`)
                            .setTimestamp()
                            .setThumbnail(interaction.member.displayAvatarURL())

                            interaction.editReply({ embeds: [nembed] })
                            }
                    }
                });

                break;
            case "check":



                todoSchema.findOne({ GuildID: guildId, UserID: interaction.member.id }, async (err, data) => {
                    if (err) throw err;

                    if (data) {
                        const loadembedsf = new EmbedBuilder()
                        .setDescription(`<a:loading:1115100728122417223> Checking task #${taskId + 1} off of your to-do list...`)
                        .setColor("#ffd870")

                        await interaction.reply({ embeds: [loadembedsf] })

                        data.Content.splice(taskId, 1);
                        data.save();
                        const asdf = new EmbedBuilder()
                        .setColor("#ffd870")
                        .setThumbnail(interaction.member.displayAvatarURL())
                        .setDescription(`Nice, task ${taskId + 1} was checked off!\n\n> Run /todo list to see your updated to-do list!`)
                        .setTimestamp();

                        interaction.editReply({ embeds: [asdf] });

                    } else if (data.Content === null){
                        const loadembedsff = new EmbedBuilder()
                        .setDescription(`<a:loading:1115100728122417223> Checking your to-do list...`)
                        .setColor("#ffd870")

                        await interaction.reply({ embeds: [loadembedsff] }) 

                        const nodt = new EmbedBuilder()
                        .setColor("#ffd870")
                            .setDescription(`<:red_cancel:1115100681129431060> You **don't have** a task to remove!`)
                            .setTimestamp();

                        await interaction.editReply({ embeds: [nodt] });
                    }
                });
                break;
            case "clear":
                
                todoSchema.findOne({ GuildID: guildId, UserID: interaction.member.id }, async (err, data) => {
                    if (err) throw err;

                    if (data) {

                        const loadembedsff = new EmbedBuilder()
                            .setDescription(`<a:loading:1115100728122417223> Clearing your to-do list...`)
                            .setColor("#ffd870")

                            await interaction.reply({ embeds: [loadembedsff] })
                

                        await todoSchema.findOneAndDelete({ GuildID: guildId, UserID: interaction.member.id });
                        const asdfasdf = new EmbedBuilder()
                        .setColor("#ffd870")
                        .setDescription(`<:green_check:1115100686682706042> Success!\n<:replyL:1115100715002634240> Deleted your to-do list!`)
                            .setTimestamp();

                       await interaction.editReply({ embeds: [asdfasdf] });

                    } else {
                        const loademdbedsff = new EmbedBuilder()
                        .setDescription(`<a:loading:1115100728122417223> Checking your to-do list...`)
                        .setColor("#ffd870")

                        await interaction.reply({ embeds: [loademdbedsff] })

                        const ssss = new EmbedBuilder()
                        .setDescription(`<:red_cancel:1115100681129431060> You have no to-do list to clear!`)
                        .setColor("#ffd870")
                            .setTimestamp();

                       await interaction.editReply({ embeds: [ssss] });
                    }
                });
                break;
        }
    }
}