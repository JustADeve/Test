const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField } = require('discord.js');
const Modlog = require('../../Schemas.js/modlog');
 
module.exports = {
    config: {
        name: "setmodlog",
        category: "Moderator",
        description: `sets up modlog`,
        usage: "modlog channel",
        type: "slash", // or "slash"
        cooldown: 5
    },
    data: new SlashCommandBuilder()
        .setName('setmodlog')
        .setDescription('Sets up the mod log channel for this server.')
        .addChannelOption(option => option.setName('channel').setDescription('The channel to set as the mod log channel').setRequired(true)),
        async execute(interaction) {
          const guildId = interaction.guild.id;
          const logChannelId = interaction.options.getChannel('channel').id;
 
          if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
              return interaction.reply({ content: '<:red_cancel:1115100681129431060> You do not have permission to use this command.', ephemeral: true });
          }
 
          try {
              let modlog = await Modlog.findOne({ guildId });
              if (modlog) {
                  return interaction.reply({ content: '<:red_cancel:1115100681129431060> A mod-logging channel has already been set up for this server.', ephemeral: true });
              }
 
              modlog = await Modlog.findOneAndUpdate(
                  { guildId },
                  { logChannelId },
                  { upsert: true }
              );
 
              return interaction.reply(`<:green_check:1115100686682706042> Mod-logging channel set to <#${logChannelId}>`);
          } catch (error) {
              console.error(error);
              return interaction.reply('<:yellow_warning:1115100685252431962> An error occurred while setting up the mod-logging channel. If this keep repeating, you can contact the developer by joining this server [here](https://discord.gg/HsGjWRd7cw)');
          }
      }
 };