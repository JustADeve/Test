const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField } = require('discord.js');
const Modlog = require('../../Schemas.js/modlog');
 
module.exports = {
    config: {
        name: "disablemodlog",
        category: "Moderator",
        description: `disables modlog`,
        usage: "disablemodlog",
        type: "slash", // or "slash"
        cooldown: 5
    },
    data: new SlashCommandBuilder()
        .setName('disablemodlog')
        .setDescription('Disables the mod log channel for this server.'),
        async execute(interaction) {
            const guildId = interaction.guild.id;
 
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return interaction.reply({ content: '<:red_cancel:1115100681129431060> You do not have permission to use this command.', ephemeral: true });
            }
 
            try {
                const modlog = await Modlog.findOne({ guildId });
                if (!modlog) {
                    return interaction.reply({ content: '<:red_cancel:1115100681129431060> Mod-logging channel has not been set up yet.', ephemeral: true });
                }
 
                await Modlog.findOneAndDelete({ guildId });
 
                return interaction.reply(`<:yellow_warning:1115100685252431962> Mod-logging channel has been disabled.`);
            } catch (error) {
                console.error(error);
                return interaction.reply('<:yellow_warning:1115100685252431962> An error occurred while disabling the mod-logging channel. If this keep repeating, you can contact the developer by joining this server [here](https://discord.gg/HsGjWRd7cw)');
            }
        },
};