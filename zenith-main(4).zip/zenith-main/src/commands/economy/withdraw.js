const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const ecoSchema = require('../../Schemas.js/economy');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('withdraw')
    .setDescription('Withdraws specified amount of money from your bank into your wallet.')
    .addStringOption(option => option.setName('amount').setDescription('Specified amount of currency will be transfered to your wallet.').setRequired(true)),
    async execute(interaction) {

        const amount = interaction.options.getString('amount');
        const { options, user, guild } = interaction;
        const Data = await ecoSchema.findOne({ Guild: interaction.guild.id, User: user.id });

        if (!Data) return await interaction.reply({ content: `You **don't** have an account to do that. Do </economy:1100070871231627388> to create an account.`, ephemeral: true});
        if (amount.startsWith('-')) return await interaction.reply({ content: `You **cannot** withdraw negative values.`, ephemeral: true})

        if (amount.toLowerCase() === 'all') {
            if(Data.Bank === 0) return await interaction.reply({ content: `You **cannot** withdraw any money because your bank is **empty**.`, ephemeral: true});

            Data.Wallet += Data.Bank;
            Data.Bank = 0;

            const embed1 = new EmbedBuilder()
            .setColor("#FFFED4")
            .setTitle(`<:green_check:1115100686682706042> Withdraw Successful`)
            .setDescription(`${user.username} has withdrawn all of  their money from their bank`)
            .setTimestamp()

            await Data.save();

            return await interaction.reply({ embeds: [embed1] })
        } else {
            const Converted = Number(amount);
            
            if(isNaN(Converted) === true) return await interaction.reply({ content: `<:red_cancel:1115100681129431060> The number inputed **is not valid**. Inputed value must be a **number** or alternetely **all**.`, ephemeral: true});

            if (Data.Bank < parseInt(Converted) || Converted === Infinity) return await interaction.reply({ content: `<:red_cancel:1115100681129431060> Eligible funds. You **cannot** transfer more than your **banks**'s balance to your wallet.`, ephemeral: true});

            Data.Wallet += parseInt(Converted);
            Data.Bank -= parseInt(Converted);
            Data.Bank = Math.abs(Data.Bank);

            await Data.save();

            const embed = new EmbedBuilder()
            .setColor("Yellow")
            .setTitle(`<:green_check:1115100686682706042> Withdraw Successful`)
            .setDescription(`${user.username} has withdrawn $**${parseInt(Converted)}** from their bank`)
            .setTimestamp()

            return await interaction.reply({ embeds: [embed]})
        }

    }
}