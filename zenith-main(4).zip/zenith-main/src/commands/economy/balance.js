const { Client, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ecoSchema = require('../../Schemas.js/economy');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('balance')
    .addUserOption(option => option.setName('user').setDescription(`Specified user's balance will be displayed.`).setRequired(false))
    .setDescription('Displays your economy balance.'),
    async execute(interaction) {

        const  {user, guild} = interaction;

        const userselected = interaction.options.getUser('user') || interaction.user;

        let Data = await ecoSchema.findOne({ Guild: interaction.guild.id, User: userselected.id});

        if (!Data) return await interaction.reply({ content: `<@${userselected.id}> **has not** opened an account yet, you cannot check an empty balance :( \n> Do </economy:1100070871231627388> to open your account.`, ephemeral: true});

        const wallet = Math.round(Data.Wallet);
        const bank = Math.round(Data.Bank);
        const total = Math.round(Data.Wallet) + Math.round(Data.Bank);

        const embed = new EmbedBuilder()
        .setColor("#FFFED4")
        .setTimestamp()
        .setTitle(`${userselected.username}'s Balance`)
        .setDescription(`   Wallet Balance - 💳 ${wallet}          \n\n   Bank Balance - 💳 ${bank}          \n\n   Total Balance - 💳 ${total}          `)
        await interaction.reply({ embeds: [embed] });
    }
}