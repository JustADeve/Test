const { Client, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const ecoSchema = require('../../Schemas.js/economy');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('economy')
    .setDescription('Creates your economy account.'),
    async execute(interaction) {

        const  {user, guild} = interaction;

        let Data = await ecoSchema.findOne({ Guild: interaction.guild.id, User: interaction.user.id});

        const embed = new EmbedBuilder()
        .setColor("Yellow")
        .setTimestamp()
        .setTitle('Economy Account Setup')
        .addFields({ name: `Options`, value: `Choose an option`, inline: false})
        .addFields({ name: `Delete`, value: `Deletes your economy account. Use with caution.`, inline: true})
        .addFields({ name: `Create`, value: `Creates your economy account.`, inline: true})

        const embed2 = new EmbedBuilder()
        .setColor("#FFFED4")
        .setTimestamp()
        .setTitle('<:green_check:1115100686682706042> Economy Account was Setup')
        .setDescription(`${interaction.user.username}, your account is now open. Here is 💳 **1000**, hope this helps you!`)

        const embed3 = new EmbedBuilder()
        .setColor("Yellow")
        .setTimestamp()
        .setTitle('<:yellow_warning:1115100685252431962> Economy Account was Terminated')

        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('page1')
            .setLabel('✅ Create')
            .setStyle(ButtonStyle.Success),

            new ButtonBuilder()
            .setCustomId('page2')
            .setLabel('❎ Delete')
            .setStyle(ButtonStyle.Danger),
        )

        const message = await interaction.reply({ embeds: [embed], components: [button] });

        const collector = await message.createMessageComponentCollector();

        collector.on('collect', async i => {

            if (i.customId === 'page1') {
                
                if (i.user.id !== interaction.user.id) {
                    return i.reply({ content: `<:red_cancel:1115100681129431060> You **cannot** use ${interaction.user.tag} menu!`, ephemeral: true})
                }

                if (!Data) {

                    Data = new ecoSchema({
                        Guild: interaction.guild.id,
                        User: user.id,
                        Bank: 0,
                        Wallet: 1000
                    })

                    await Data.save();

                    await i.update({ embeds: [embed2], components: [] });
                } else {
                    return i.reply({ content: `<:red_cancel:1115100681129431060> You **already** have an account, you cannot create another one.`, ephemeral: true})
                }
            }

            if (i.customId === 'page2') {

                if (!Data) {
                    return i.reply({ content: `<:red_cancel:1115100681129431060> You **do not** have an account yet, can't delete nothing.`, ephemeral: true})
                } else {

                    if (i.user.id !== interaction.user.id) {
                        return i.reply({ content: `You **cannot** use ${interaction.user.tag} menu!`, ephemeral: true})
                    }

                    await ecoSchema.deleteMany({ Guild: interaction.guild.id, User: interaction.user.id }); 

                    await i.update({ embeds: [embed3], components: [] });
                }
            }
        })
    }
}