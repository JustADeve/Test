const { Client, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const ecoSchema = require('../../Schemas.js/economy');
var timeout = [];

module.exports = {
    data: new SlashCommandBuilder()
    .setName('beg')
    .setDescription('Beg for some money.'),
    async execute(interaction) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator) && timeout.includes(interaction.member.id)) return await interaction.reply({ content: 'You are on cooldown! You **cannot** execute </beg:1100070871231627387>', ephemeral: true})

        timeout.push(interaction.user.id);
        setTimeout(() => {
            timeout.shift();
        }, 10000)

        const  {user, guild} = interaction;

        let Data = await ecoSchema.findOne({ Guild: interaction.guild.id, User: user.id});

        if (!Data) return await interaction.reply({ content: `<:red_cancel:1115100681129431060> You **have not** opened an account yet, you cannot earn any money without an account :( \n> Do </economy:1100070871231627388> to open your account.`, ephemeral: true});

        let negative = Math.round((Math.random() * -300) - 10)
        let positive = Math.round((Math.random() * +300) + 10)

        const posN = [negative, positive];

        const amount = Math.round((Math.random() * posN.length));
        const value = posN[amount];

        if (!value) return await interaction.reply({ content: `You were **rejected**. No money this time :(`, ephemeral: true});

        if (Data) {
            Data.Wallet += value;
            await Data.save();
        }

        if (value > 0) {

            const embed1 = new EmbedBuilder()
            .setColor("#FFFED4")
            .setTimestamp()
            .setFooter({ text: "Beg Successfully"})
            .setTitle('<:green_check:1115100686682706042> Begging Succeeded')
            .setDescription(`Someone gave you \`\`\`$${value}\`\`\``)

            await interaction.reply({ embeds: [embed1] });
        } else {

            const stringv = `${value}`;

            const nonSymbol = await stringv.slice(1);

            const embed2 = new EmbedBuilder()
            .setColor("Yellow")
            .setTimestamp()
            .setFooter({ text: "Begging Unsuccessfully "})
            .setTitle(' Begging was a Mistake')
            .setDescription(`Begging is not always the option deer, you lost \`\`\`$${nonSymbol}\`\`\``)

            await interaction.reply({ embeds: [embed2]})
        }
    }
}