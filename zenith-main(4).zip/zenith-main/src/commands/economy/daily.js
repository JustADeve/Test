const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const ecoS = require('../../Schemas.js/economy');
 
var timeout = [];
 
module.exports = {
    data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Allows you to claim a random amount of currency each day.'),
 
    async execute(interaction) {
        const { options, guild, user } = interaction;
        
        let data = await ecoS.findOne({ Guild: guild.id, User: user.id });
 
        if (timeout.includes(interaction.user.id) && interaction.user.id !== '751708824796266558') return await interaction.reply({ content: "You have **already** claimed your daily amount! Please check back **later**.", ephemeral: true });
 
        if (!data) return await interaction.reply({ content: "<:red_cancel:1101072836874997790> You **don't** have an account yet! \n> Do </economy:1100070871231627388> to configure your account.", ephemeral: true });
        else {
            const randAmount = Math.round((Math.random() * 3000) + 10);
 
            data.Wallet += randAmount;
            data.save();
 
            const embed = new EmbedBuilder()
                .setColor('#FFFED4')
                .setTitle('<:green_check:1115100686682706042> Daily Allowance Claimed')
                .setDescription(`Amount: **$${randAmount}**. You can claim again in the next **12 hours**!`)
                .setTimestamp();
 
            await interaction.reply({ embeds: [embed] });
 
            timeout.push(interaction.user.id);
            setTimeout(() => {
                timeout.shift();
            }, 43200000);
        }
    }
}