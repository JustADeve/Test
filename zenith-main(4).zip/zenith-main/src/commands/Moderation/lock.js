const {SlashCommandBuilder} = require(`@discordjs/builders`);
const {ChannelType} = require('discord-api-types/v10');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('This locks a given channel')
    .addChannelOption(option => option.setName('channel').setDescription('The channel that you wanna lock').addChannelTypes(ChannelType.GuildText).setRequired(true)),
    async execute (interaction) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) return await interaction.reply({content: "You don't have permission to execute this command", ephemeral: true})

        let channel = interaction.options.getChannel('channel');

        channel.permissionOverwrites.create(interaction.guild.id, {SendMessages: false})

        const embed = new EmbedBuilder()
        .setColor('#da99ff')
        .setDescription(`<:green_check:1115100686682706042> ${channel} has successfully been **locked**!`)

        await interaction.reply ({embeds: [embed] })    
    }
}