const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mass-unban')
        .setDescription('Unban all members in the server. Use with caution!'),
    async execute(interaction) {
        
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({ content: '<:red_cancel:1115100681129431060> You **don\'t** have the permission to do that!', ephemeral: true});

        try {
            
            const bannedMembers = await interaction.guild.bans.fetch();
            
            await Promise.all(bannedMembers.map(member => {
                return interaction.guild.members.unban(member.user.id);
            }));
           
            return interaction.reply({ content: '<:green_check:1115100686682706042> All members have been **unbanned** from the server.', ephemeral: true });
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: '<:yellow_warning:1115100685252431962> An error occurred while **unbanning** members.', ephemeral: true });
        }
    }
}