const { Client, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Embed, PermissionsBitField } = require('discord.js');
const { Schema } = require('mongoose');
const warnSchema = require('../../Schemas.js/warnSchema');
 
module.exports ={
    data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user.')
    .addSubcommand(command => command.setName('user').setDescription('Warn a user.').addUserOption(option => option.setName('user').setDescription('The user who you want to warn.').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('Reason for the warn.')))
    .addSubcommand(command => command.setName('show')
    .setDescription('View a user\'s warnings.')
    .addUserOption(option => option.setName('user').setDescription('The user who\'s warns you want to see.')))
    .addSubcommand(command => command.setName('remove').setDescription('Remove a user\'s warning.').addUserOption(option => option.setName('user').setDescription('The user who\'s warn you want to remove.').setRequired(true))
    .addIntegerOption(option => option.setName('warn').setDescription('The warning you want to get rid of from the selected user.').setRequired(true))),
    async execute (interaction)
    {
 
        const command = interaction.options.getSubcommand()
 
        if (command === 'user')
        {
 
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return await interaction.reply({ content: '<:red_cancel:1115100681129431060> You need the Moderate Members permission to use this command.', ephemeral: true })
 
            const warnedUser = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || 'No reason was given';
 
            if (warnedUser.bot) return await interaction.reply({ content: '<:red_cancel:1115100681129431060> You cannot warn a bot.', ephemeral: true })
 
            let Data = await warnSchema.findOne({ UserID: interaction.options.getUser('user').id, GuildID: interaction.guild.id })
 
            const unwarnedEmbed = new EmbedBuilder()
            .addFields({ name: 'UnWarned!', value: `><:yellow_warning:1115100685252431962> You did not warn **${warnedUser}** with the reason of **${reason}**. \n\nYou have cancelled the warning.` })
            .setColor('#ffb553')
            .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}`})
            .setTimestamp()
 
            const warnedEmbed = new EmbedBuilder()
            .addFields({ name: 'Warned!', value: `> <:yellow_warning:1115100685252431962> You have warned **${warnedUser}** with the reason of **${reason}**.` })
            .setColor('#ffb553')
            .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}`})
            .setTimestamp()
 
            const warningEmbed = new EmbedBuilder()
            .addFields({ name: 'Warning!', value: `> <:yellow_warning:1115100685252431962> You will warn **${warnedUser}**> With the reason of **${reason}**.\n\n> Do you want to warn him?` })
            .setColor('Blue')
            .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}`})
            .setTimestamp()
 
            const confirmButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setCustomId('confirm')
                    .setLabel('Confirm')
                    .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                    .setCustomId('decline')
                    .setLabel('Not Sure')
                    .setStyle(ButtonStyle.Danger),
                )
            var message = await interaction.reply({ embeds: [warningEmbed], components: [confirmButton] })
 
            const collector = message.createMessageComponentCollector()
 
            collector.on('collect', async i => {
 
                if (i.user.id != interaction.user.id) return await i.reply({ content: 'This isn\'t your command!', ephemeral: true })
 
                if (i.customId == 'confirm')
                {
 
                    if (!Data)
                    {
                        Data = new warnSchema({
                            UserID: warnedUser.id,
                            GuildID: interaction.guild.id,
                        })
 
                    }
 
                    await i.reply({ content: '<:green_check:1115100686682706042> Confirmed! You have warned him! If you want to unwarn, execute </warn remove:1098138880437391370> command. \n Use </warn show:1098138880437391370> to check someone\'s warnings', ephemeral: true })
                    await interaction.editReply({ embeds: [warnedEmbed], components: [] })
                    Data.Warns.push(reason)
 
                    const dmEmbed = new EmbedBuilder()
                    .addFields({ name: '<:green_check:1115100686682706042> You have been warned!', value: `You have been warned in ${interaction.guild.name} \nFor the reason of ${reason}` })
                    .setColor('Red')
                    .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}`})
                    await warnedUser.send({ embeds: [dmEmbed] }).catch(err => {
                        return;
                    })
 
                    await Data.save()
 
                }
                else {
 
                    await i.reply({ content: '<:red_cancel:1115100681129431060> Declined! You have canceled this warning! If you want to warn again, try to use </warn user:1098138880437391370> command. ', ephemeral: true })
                    await interaction.editReply({ embeds: [unwarnedEmbed], components: [] })
 
                }
 
            })
 
        }
 
 
        if (command === 'show')
        {
 
            const warnsUser = interaction.options.getUser('user') || interaction.user;
 
            let DataWarns = await warnSchema.findOne({ UserID: warnsUser.id, GuildID: interaction.guild.id })
 
            if ((!DataWarns || DataWarns.Warns.length == 0) && command === 'show')
            {
 
                const noWarnsEmbed = new EmbedBuilder()
                .setTitle('No warnings!')
                .addFields({ name: '0 warnings!', value: `${warnsUser} has no warnings!` })
                .setColor('Blue')
                .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}` })
                return await interaction.reply({ embeds: [noWarnsEmbed] })
 
            }
 
            else {
 
                let numberOfWarns1 = 0
                let numberOfWarns = 1
                let warns = ''
 
                for (i in DataWarns.Warns)
                {
 
                    warns += `**Warning** **${numberOfWarns}**\n${DataWarns.Warns[numberOfWarns1]}\n\n `
 
                    numberOfWarns += 1
                    numberOfWarns1 += 1
 
                }
 
                const showWarnsEmbed = new EmbedBuilder()
                .setAuthor({ name: `${warnsUser.username}'s warnings in ${interaction.guild.name}`})
                .setDescription(warns)
                .setColor('Blue')
                .setFooter({ text: `${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp()
 
                await interaction.reply({ embeds: [showWarnsEmbed] })
 
            }
        }
 
        if (command === 'remove')
        {
 
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) return await interaction.reply({ content: 'You need the Moderate Members permission to use this command.', ephemeral: true })
 
            removeWarnUser = interaction.options.getUser('user');
            warnRemoved = interaction.options.getInteger('warn')
            warnRemoved -= 1
 
            let DataUnwarned = await warnSchema.findOne({ UserID: interaction.options.getUser('user').id, GuildID: interaction.guild.id })
 
            if (!DataUnwarned || DataUnwarned.Warns.length == 0)
            {
                const noWarnsEmbed = new EmbedBuilder()
                .setTitle('No warnings!')
                .addFields({ name: '0 warnings!', value: `${removeWarnUser} has no warnings to remove!` })
                .setColor('Blue')
                .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}` })
                return await interaction.reply({ embeds: [noWarnsEmbed] })
            }
 
            if (DataUnwarned.Warns[warnRemoved] == undefined)
            {
                const highWarnEmbed = new EmbedBuilder()
                .setTitle('No warnings found!')
                .addFields({ name: 'No warning found!', value: `You didn't specify a warn that is within the range of ${removeWarnUser}'s warns.\nUse </warn show:1098138880437391370> to see their warns.` })
                .setColor('Blue')
                .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}` })
                return await interaction.reply({ embeds: [highWarnEmbed] })
            }
 
 
            const removedWarnEmbed = new EmbedBuilder()
            .addFields({ name: 'Warning removed!', value: `You have removed ${removeWarnUser}'s warn\n About: **${DataUnwarned.Warns[warnRemoved]}**` })
            .setColor('Blue')
            .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}` })
            const dmEmbed = new EmbedBuilder()
            .setTitle('Unwarned!')
            .addFields({ name: 'You have been unwarned!', value: `You have been unwarned in ${interaction.guild.name}!\nThe warn removed was : ${DataUnwarned.Warns[warnRemoved]}` })
            .setColor('#ffb553')
            .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL()}`})
            await removeWarnUser.send({ embeds: [dmEmbed] }).catch(err => {
                return;
            })
            DataUnwarned.Warns.splice(DataUnwarned.Warns[warnRemoved], 1)
            DataUnwarned.save()
            return await interaction.reply({ embeds: [removedWarnEmbed] })
        }
 
    }
}