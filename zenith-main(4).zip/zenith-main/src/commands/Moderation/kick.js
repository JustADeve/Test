const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('kick')
    .setDMPermission(false)
    .setDescription('Kicks specified user.')
    .addUserOption(option => option.setName('user').setDescription('Specify the user you want to kick.').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('Reason as to why you want to kick specified user.').setRequired(false)),
    async execute(interaction, client) {
        
        const users = interaction.options.getUser('user');
        const ID = users.id;
        const kickedmember = interaction.options.getMember('user');

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) return await interaction.reply({ content: '<:red_cancel:1115100681129431060> You **do not** have the permission to do that!', ephemeral: true});
        if (interaction.member.id === ID) return await interaction.reply({ content: '<:red_cancel:1115100681129431060> You **cannot** use the kick power on you, silly goose..', ephemeral: true});

        if (!kickedmember) return await interaction.reply({ content: `<:yellow_warning:1115100685252431962> That user **does not** exist within your server.`, ephemeral: true});
    
        const reason = interaction.options.getString('reason') || 'No reason provided :(';
        
        const dmembed = new EmbedBuilder()
        .setColor("#F7C5DD")
        .setTitle(`<:sadge:1115100726012694558> You were kicked from "${interaction.guild.name}"`)
        .setDescription(`<:arrow:1115100703069831270> Server: \`${interaction.guild.name}\` \n <:arrow:1115100703069831270> Reason: \`${reason}\``)
        .setTimestamp()

        const embed = new EmbedBuilder()
        .setColor("#F7C5DD")
        .setTitle(`<:green_check:1115100686682706042> User was kicked!`)
        .setDescription(`<:arrow:1115100703069831270> User: \`${users.tag}\` \n <:arrow:1115100703069831270> Reason: \`${reason}\``)    
        .setTimestamp()

        await kickedmember.kick().catch(err => {
            return interaction.reply({ content: `<:red_cancel:1115100681129431060> **Couldn't** kick this member! Check my **role position** and try again.`, ephemeral: true});
        })

        await kickedmember.send({ embeds: [dmembed] }).catch(err => {
            return;
        })

        await interaction.reply({ embeds: [embed] });
    }
}