const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set the slowmode in a channel')
    .addIntegerOption(option => option.setName('duration').setDescription('The time of the slowmode. Must be in seconds, eg: 10 (no need s)').setRequired(true))
    .addChannelOption(option => option.setName('channel').setDescription('The channel that you want to set the slowmode in').addChannelTypes(ChannelType.GuildText).setRequired(true)),
    async execute (interaction) {

        const { options } = interaction;
        const duration = options.getInteger('duration');
        const channel = options.getChannel('channel') || interaction.channel;

        const embed = new EmbedBuilder()
        .setColor("#F7C5DD")
        .setDescription(`<:green_check:1115100686682706042> ${channel} now has ${duration} seconds of **slowmode**`)

        channel.setRateLimitPerUser(duration).catch(err => {
            return;
        })
        await interaction.reply({ embeds: [embed] });
    }
}