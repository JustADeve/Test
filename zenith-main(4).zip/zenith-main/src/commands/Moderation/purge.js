const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionsBitField, Permissions } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete a specified amount of messages!')
    .addIntegerOption(int => int.setName('amount').setDescription('The amount of messages to be deleted!').setRequired(true))
    .addUserOption(user => user.setName('user').setDescription('The messages of the selected user will be deleted, leave empty to purge messages from any user!')),
    async execute(interaction) {
        try {
        await interaction.deferReply({ ephemeral: true })
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return await interaction.editReply('Insufficient permissions!');
        
        
        const purgeUser = await interaction.options.getUser('user');
        const int = await interaction.options.getInteger('amount');
       
        if (purgeUser) {
            
            const messages = await interaction.channel.messages.fetch({ limit: int });
            const userMessages = await messages.filter(msg => msg.author.id === purgeUser.id);
            const deletedMessages = userMessages.size;
           
           
            const embed = new EmbedBuilder()
            .setTitle('**Messages Purged**')
            .setDescription(`<:green_check:1115100686682706042> \`${deletedMessages}/100\` messages were purged from user <@${purgeUser.id}>!`)
            .setColor('Green')

            await await interaction.channel.messages.fetch({ limit: int }).then((messages) => { 
                let userMsgs = [];
                 messages.filter(m => m.author.id === purgeUser.id).forEach(msg => userMsgs.push(msg))
                 interaction.channel.bulkDelete(userMsgs);
              
                 interaction.editReply({ embeds: [embed]});
          });
        }else {
        const messages = await interaction.channel.messages.fetch({ limit: int });
        const deletedMessages = messages.size;
        const successEmbed = new EmbedBuilder()
        .setTitle('**Purge Successful!**')
        .addFields({ name: '**Messages deleted:**', value: `\`${deletedMessages}/100\` messages were deleted!` })
        .setFooter({ text: 'Purged messages!', iconURL: interaction.user.displayAvatarURL() })
        .setColor('Green')

        await interaction.channel.bulkDelete(int);
        await interaction.editReply({ embeds: [successEmbed]});}
    } catch(err) {
        return await interaction.editReply('An error occured, try again or decrease the number of messages you want to delete.' + err)
    }
        
    },
};