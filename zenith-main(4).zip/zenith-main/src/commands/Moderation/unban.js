const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user from you server')
    .addUserOption(option => option.setName('user').setDescription('The member that you want to unban').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('The reason for unbanning the member').setRequired(true)),
    async execute(interaction, client) {

        const userID = interaction.options.getUser('user');

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers)) return await interaction.reply ({content: "<:red_cancel:1115100686682706042> You must have the ban permission to use this command", ephemeral: true});
        if (!interaction.member.id == userID) return await interaction.reply ({content: "<:red_cancel:1115100686682706042> You cannot ban yourself!", ephemeral: true});

        let reason = interaction.options.getString('reason');
        if (!reason) reason = "No reason was given";

        const embed = new EmbedBuilder()
        .setColor("#5cff53")
        .setDescription(`<:green_check:1115100686682706042> <@${userID}> has been banned\n<:arrow:1115100703069831270> Reason: ${reason}`)

        await interaction.guild.bans.fetch()
        .then(async bans => {

            if (bans.size == 0) return await interaction.reply({content: "<:red_cancel:1115100686682706042> There is no one banned from this guild", ephemeral: true})
            let bannedID = bans.find(ban => ban.user.id == userID);
            if (!bannedID) return await interaction.reply({content: "<:yellow_warning:1115100685252431962> The ID stated is not banned in this guild", ephemeral: true})

            await interaction.guild.bans.remove(userID, reason).catch(err => {
                return interaction.reply({content: "<:yellow_warning:1115100685252431962> I cannot unban this user"})
            })
        })

        await interaction.reply({ embeds: [embed] });
    }
}
