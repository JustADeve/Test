const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const ghostSchema = require('../../Schemas.js/ghostpingSchema');
const numSchema = require('../../Schemas.js/ghostNum');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('anti-ghostping')
    .setDescription('Setup the anti-ghost-ping system')
    .addSubcommand(command => command.setName('setup').setDescription('Setup the anit ghost ping system'))
    .addSubcommand(command => command.setName('disable').setDescription('Disable the anti-ghost-ping system in this server'))
    .addSubcommand(command => command.setName('number-reset').setDescription('Reset a user ghost ping amount').addUserOption(option => option.setName('user').setDescription('The user that you want to reset the number of ghost ping of').setRequired(true))),
    async execute (interaction) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({ content: '<:red_cancel:1115100681129431060> You dont have permission to manage the anti ghost ping system', ephemeral: true})

        const { options } = interaction;
        const sub = options.getSubcommand();

        const Data = await ghostSchema.findOne({Guild: interaction.guild.id});

        switch (sub) {
            case 'setup':

            if (Data) return await interaction.reply({content: '<:red_cancel:1115100681129431060> You already have setup the anti-ghost-ping system in your server!', ephemeral: true});
            else {
                await ghostSchema.create({
                    Guild: interaction.guild.id
                })

                const embed = new EmbedBuilder()
                .setColor("#5cff53")
                .setTitle('<:green_check:1115100686682706042> Successfully Setup Anti-Ghost-Ping')
                .setFooter({ text: "Enable Anti-Ghost-Ping"})
                .setTimestamp()
                .setDescription(`The anti-ghost-ping system has been setup in your server!`)
                
                await interaction.reply({ embeds: [embed] });
            }

            break;

            case 'disable':

            if (!Data) return await interaction.reply({content: '<:red_cancel:1115100681129431060> There is no anti-ghost-ping system setup here', ephemeral: true})
            else {
                await ghostSchema.deleteMany({ Guild: interaction.guild.id});

                const embed = new EmbedBuilder()
                .setColor("#5cff53")
                .setTitle('<:green_check:1115100686682706042> Successfully Disable Anti-Ghost-Ping')
                .setFooter({ text: "Disable Anti-Ghost-Ping"})
                .setTimestamp()
                .setDescription(`The anti-ghost-ping system has been disabled in your server!`)
                
                await interaction.reply({ embeds: [embed] });
            }

            break ;

            case 'number-reset':

            const member = options.getUser('user');
            const data = await numSchema.findOne({ Guild: interaction.guild.id, User: member.id});

            if (!Data) return await interaction.reply({content: '<:red_cancel:1115100681129431060> This member doesnt have any ghost ping yet', ephemeral: true});
            else {
                await data.deleteOne({User: member.id});

                await interaction.reply({content: `<:yellow_warning:1115100685252431962> ${member}'s ghost ping number is back to 0`})
            }
        }
    }
}