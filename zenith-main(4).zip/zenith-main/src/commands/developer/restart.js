const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
 
module.exports = {
    data: new SlashCommandBuilder()
    .setName('restart')
    .setDescription('Shuts down Zenith. Only the developer of Zenith Bot can use this command. Use twice for shutdown.'),
    async execute(interaction, client) {
 
        if (interaction.user.id === `751708824796266558`) {
            await interaction.reply({ content: `<a:loading:1115100728122417223> **Shutting down..**`, ephemeral: true})
            await client.user.setStatus("invisible")
            process.exit();
        } else {
            return interaction.reply({ content: `<:red_cancel:1115100681129431060> Only **developers**( <@751708824796266558> ) can use this command!`, ephemeral: true})
        }
    }
}