const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName("leave-guild")
    .setDescription("make the bot leave a server")
    .addStringOption(option =>
      option.setName("guildid")
          .setDescription("guildid")
          .setRequired(true)
    ),
                   
    async execute(interaction, client) {

        const botOwnerId = '751708824796266558';

        const ownerOnly = new EmbedBuilder()
        .setTitle(`<:red_cancel:1115100681129431060> Error!`)
        .setDescription('Only **developers**( <@751708824796266558> ) can use this command!')
        .setColor('Red')

        if(interaction.member.id !== botOwnerId) return interaction.reply({ embeds: [ownerOnly], ephemeral: true})

        const leavingEmbed = new EmbedBuilder()

        .setTitle(`Loading`)
        .setDescription('<a:loading:1115100728122417223> leaving that server...')
        .setColor('Blue')

        await interaction.reply({ embeds: [leavingEmbed], ephemeral: true })

        const guildid = interaction.options.getString("guildid");

        const guild = client.guilds.cache.get(guildid)

        const errEmbed = new EmbedBuilder()
        .setTitle(`Error! Bot is not in the server!`)
        .setDescription('Maybe the bot is not inside the server. use `?servers` to check all the servers that invited zenith bot and server id.')
        .setColor('Red')

        if (!guild) await interaction.editReply({ embeds: [errEmbed], ephemeral: true })
        else {
            await guild.leave().catch(err => {
                return interaction.editReply({ embeds: [errEmbed], ephemeral: true });
            });
            const successEmbed = new EmbedBuilder()
            .setTitle(`Left Server`)
            .setDescription('I have left that server!')
            .setColor('Green')

            await interaction.editReply({ embeds: [successEmbed], ephemeral: true })
        }
    }
}