const { SlashCommandBuilder, EmbedBuilder } = require ('discord.js')
const afkSchema = require ('../../Schemas.js/afkSchema') 

module.exports = {
    data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Leave an server AFK message for the users who contatcs you while you are away!')
    .addSubcommand(command => command.setName('set').setDescription('Go afk within your server').addStringOption(option => option.setName('message').setDescription('the reason for going afk').setRequired(false)))
    .addSubcommand(command => command.setName('remove').setDescription('Remove your afk in your server')),
    async execute (interaction) {

        const { options } = interaction;
        const sub = options.getSubcommand ()

        const Data = await afkSchema.findOne ({ Guild: interaction.guild.id, User: interaction.user.id});

        switch (sub) {
                case 'set':

            if (Data) return await interaction.reply ({content: `<:red_cancel:1115100681129431060> You are already afk in this server, this means that you need to remove the current afk to set a new afk!`, ephemeral: true});
            else {
                const message = options.getString('message');
                const nickname = interaction.member.nickname || interaction.user.username;
                await afkSchema.create ({
                    Guild: interaction.guild.id,
                    User: interaction.user.id,
                    Message: message,
                    Nickname: nickname
                })

                const name = `[AFK] ${nickname}`;
                await interaction.member.setNickname(`${name}`).catch (err => {
                return;
                })

                const embed = new EmbedBuilder ()
                .setColor("#5cff53")
                .setTitle('You are now AFK! <:zenith_afk:1124310104225882122> ')
                .setTimestamp()
                .setFooter({ text: "AFK Command"})
                .setDescription(`You are now afk in the server. You will be removed from AFK when you send a message or use </afk remove:1096049281514881104> \`\`\`${message}\`\`\``)

                await interaction.reply({ embeds: [embed]});
            }

            break;

            case `remove`:

            if (!Data) return await interaction.reply({content: `<:red_cancel:1115100681129431060> Unfortunally, you are not afk in this server. If this keep repeating, you can contact the developer by joining this server [here](https://discord.gg/HsGjWRd7cw)`, ephemeral: true});
            else{
                const nick = Data.Nickname;
                await afkSchema.deleteMany({ Guild: interaction.guild.id, User: interaction.user.id});

                await interaction.member.setNickname(`${nick}`).catch(err => {
                    return;
                 })

                 const embed = new EmbedBuilder ()
                 .setColor("#5cff53")
                 .setTitle('<:green_check:1115100686682706042> Your AFK has been removed!')
                 .setDescription(`Your AFK has been Removed!`)

                 await interaction.reply({embeds: [embed], ephemeral: true})

            }
        }
    }
}