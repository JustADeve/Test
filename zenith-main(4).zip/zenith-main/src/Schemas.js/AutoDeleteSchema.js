const mongoose = require('mongoose');

const autoDeleteSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
  },
  channelId: {
    type: String,
    required: true,
  },
  userOption: {
    type: Boolean,
    required: true,
  },
  timeInterval: {
    type: Number,
    required: true,
  },
});

const AutoDelete = mongoose.model('AutoDelete', autoDeleteSchema);

module.exports = AutoDelete;
