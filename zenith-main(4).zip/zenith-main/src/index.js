const { Client, GatewayIntentBits, Partials, EmbedBuilder, PermissionsBitField, Permissions, MessageManager, Embed, Collection, Events } = require(`discord.js`);
const fs = require('fs');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.GuildMembers, GatewayIntentBits.DirectMessages, GatewayIntentBits.GuildPresences, GatewayIntentBits.GuildVoiceStates, GatewayIntentBits.GuildMessageReactions, GatewayIntentBits.DirectMessageReactions, GatewayIntentBits.DirectMessageTyping], partials: [Partials.Channel, Partials.Reaction, Partials.Message] }); 
const {handleLogs} = require("./events/handleLogs");
const { CaptchaGenerator } = require('captcha-canvas');
const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, MessageType, AuditLogEvent} = require('discord.js');
const { TextInputStyle } = require('discord.js');
const { ComponentType, SelectMenuBuilder, ChannelType, StringSelectMenuBuilder,  UserFlagsBitField, InteractionResponse, ReactionUserManager, TextChannel } = require('discord.js');
const { createTranscript } = require('discord-html-transcripts');
const fetch = require('node-fetch');

client.commands = new Collection();


require('dotenv').config();


// Schema 
const joinschema = require('./Schemas.js/jointocreate');
const joinchannelschema = require('./Schemas.js/jointocreatechannels');
const voiceschema = require('./Schemas.js/voicechannels');
const botschema = require('./Schemas.js/botsvoicechannels');
const modschema = require('./Schemas.js/modmailschema');
const moduses = require('./Schemas.js/modmailuses');
const pollschema = require('./Schemas.js/votes')
const birthdayschema = require("./Schemas.js/birthdays");
const birthdaysetups = require('./Schemas.js/birthdayschema');
const Modlog = require('./Schemas.js/modlog');
const AutoDeleteSchema = require('./Schemas.js/AutoDeleteSchema');
const reactor = require('./Schemas.js/reactorschema');

const functions = fs.readdirSync("./src/functions").filter(file => file.endsWith(".js"));
const eventFiles = fs.readdirSync("./src/events").filter(file => file.endsWith(".js"));
const commandFolders = fs.readdirSync("./src/commands");
const GiveawaysManager = require("./utils/giveaway");

client.giveawayManager = new GiveawaysManager(client, {
    default: {
      botsCanWin: false,
      embedColor: "#B4D5F9",
      embedColorEnd: "#EDC4BC",
      reaction: "🎉",
    },
});

//Handle All Errors
client.on("error", (err) => {
    const ChannelID = "1115101084227215430";
    console.log("Discord API Error:", err);
    const Embed = new EmbedBuilder()
      .setColor("#CFC5F6")
      .setTimestamp()
      .setFooter({ text: "⚠️ Anti Crash system" })
      .setTitle("Error Encountered");
    const Channel = client.channels.cache.get(ChannelID);
    if (!Channel) return;
    Channel.send({
      embeds: [
        Embed.setDescription(
          "**Discord API Error/Catch:\n\n** ```" + err + "```"
        ),
      ],
    });
  });
  
  process.on("unhandledRejection", (reason, p) => {
    const ChannelID = "1115101084227215430";
    console.log("Unhandled promise rejection:", reason, p);
    const Embed = new EmbedBuilder()
      .setColor("#CFC5F6")
      .setTimestamp()
      .setFooter({ text: "⚠️ Anti Crash system" })
      .setTitle("Error Encountered");
    const Channel = client.channels.cache.get(ChannelID);
    if (!Channel) return;
    Channel.send({
      embeds: [
        Embed.setDescription(
          "**Unhandled Rejection/Catch:\n\n** ```" + reason + "```"
        ),
      ],
    });
  });
  
  process.on("uncaughtException", (err, origin) => {
    const ChannelID = "1115101084227215430";
    console.log("Uncaught Exception:", err, origin);
    const Embed = new EmbedBuilder()
      .setColor("#CFC5F6")
      .setTimestamp()
      .setFooter({ text: "⚠️ Anti Crash system" })
      .setTitle("Error Encountered");
    const Channel = client.channels.cache.get(ChannelID);
    if (!Channel) return;
    Channel.send({
      embeds: [
        Embed.setDescription(
          "**Uncought Exception/Catch:\n\n** ```" + err + "```"
        ),
      ],
    });
  });
  
  process.on("uncaughtExceptionMonitor", (err, origin) => {
    const ChannelID = "1115101084227215430";
    console.log("Uncaught Exception Monitor:", err, origin);
    const Embed = new EmbedBuilder()
      .setColor("#CFC5F6")
      .setTimestamp()
      .setFooter({ text: "⚠️ Anti Crash system" })
      .setTitle("Error Encountered");
    const Channel = client.channels.cache.get(ChannelID);
    if (!Channel) return;
    Channel.send({
      embeds: [
        Embed.setDescription(
          "**Uncaught Exception Monitor/Catch:\n\n** ```" + err + "```"
        ),
      ],
    });
  });
  
  process.on("warning", (warn) => {
    const ChannelID = "1115101084227215430";
    console.log("Warning:", warn);
    const Embed = new EmbedBuilder()
      .setColor("#CFC5F6")
      .setTimestamp()
      .setFooter({ text: "⚠️ Anti Crash system" })
      .setTitle("Error Encountered");
    const Channel = client.channels.cache.get(ChannelID);
    if (!Channel) return;
    Channel.send({
      embeds: [
        Embed.setDescription(
          "**Warning/Catch:\n\n** ```" + warn + "```"
        ),
      ],
    });
  });
// Commands //

(async () => {
    for (file of functions) {
        require(`./functions/${file}`)(client);
    }
    client.handleEvents(eventFiles, "./src/events");
    client.handleCommands(commandFolders, "./src/commands");
    client.login(process.env.token)
})();


      // Ping Bot + Fun //

client.on(Events.MessageCreate, async message => {

    if (message.author.bot) return;

    const inputmessage = message.content.toLowerCase();

    if (message.content == '<@1096048779641237635>' || inputmessage === 'hey zenith' && message.author.id !== '1096048779641237635') {

        const msg = await message.reply({ content: `Hello there **${message.author}**\n My name is **Zenith**.\n<:replyL:1115100715002634240> Don't know how to use me?\n<:replyL:1115100715002634240> Simply use  </bot help:1100634582329597972> to get a list of my features!\n > Thanks for Inviting Zenith\n > Join My Support Server Here: https://discord.gg/HsGjWRd7cw`});
    }

    if (inputmessage.includes('zenith sucks') && message.author.id === '751708824796266558' && message.author.id !== '1096048779641237635') {

        const msg = await message.reply({ content: `Bro what the hell bro, I am literaly your son 😭`});

    } else if (inputmessage.includes('zenith sucks') && message.author.id !== '1096048779641237635') {

        const msg = await message.reply({ content: `:(`})

    }
})

// Feedback Form
client.on(Events.InteractionCreate, async (interaction) => {

    const channelID = '1115101100392058950';

    if (!interaction.isModalSubmit()) return;
  
    if (interaction.customId === "modal") {
      const name = interaction.fields.getTextInputValue("name");
      const mark = interaction.fields.getTextInputValue("mark");
      const feedbackfeeling = interaction.fields.getTextInputValue("feedbackfeeling");
      const problem = interaction.fields.getTextInputValue("problem");

  
      const id = interaction.user.id;
      const tag = interaction.user.tag;
  
      const embed = new EmbedBuilder()
        .setColor('#FFDEDE')
        .setTitle(`New Feedback from ${tag} (${id})`)
        .setDescription(`**User Name:**\n\`${name}\`\n**Out of 10, how many you will give to Zenith:** \n \`${mark}\`\n**Provide us what do you think about Zenith**\n \`${feedbackfeeling}\`\n**Problem when using Zenith**\n\`${problem}\``)
  
          const channel = interaction.guild.channels.cache.get(channelID);
  
          channel.send({ embeds: [embed] });
  
          await interaction.reply({
            content: `<:yay_yay:1102439544835543111> Your feedback has successfully been sent!`,
            ephemeral: true,
          });
        }
      });

// Poll

client.on(Events.InteractionCreate, async i => {
 
    if (!i.guild) return;
    if (!i.message) return;
    if (!i.isButton) return;
 
    const data = await pollschema.findOne({ Guild: i.guild.id, Msg: i.message.id });
    if (!data) return;
    const msg = await i.channel.messages.fetch(data.Msg)
 
        if (i.customId === 'up') {
 
            if (i.user.id === data.Owner) return await i.reply({ content: `<:red_cancel:1115100681129431060> You **cannot** upvote your own **suggestion**!`, ephemeral: true });
            if (data.UpMembers.includes(i.user.id)) return await i.reply({ content: `<:red_cancel:1115100681129431060> You have **already** upvoted this **suggestion**`, ephemeral: true});
 
            let downvotes = data.Downvote;
            if (data.DownMembers.includes(i.user.id)) {
                downvotes = downvotes - 1;
            }
 
            const newembed = EmbedBuilder.from(msg.embeds[0]).setFields({ name: `Upvotes`, value: `> **${data.Upvote + 1}** Votes`, inline: true}, { name: `Downvotes`, value: `> **${downvotes}** Votes`, inline: true}, { name: `Original Author`, value: `> <@${data.Owner}>`});
 
            const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('up')
                .setEmoji('<:green_thumb_up:1115100692961574912>')
                .setLabel(`${data.Upvote + 1}`)
                .setStyle(ButtonStyle.Secondary),
 
                new ButtonBuilder()
                .setCustomId('down')
                .setEmoji('<:red_thumb_down:1115100724532084808>')
                .setLabel(`${downvotes}`)
                .setStyle(ButtonStyle.Secondary),
 
                new ButtonBuilder()
                .setCustomId('votes')
                .setLabel('Who Voted?')
                .setStyle(ButtonStyle.Secondary)
            )
 
            await i.update({ embeds: [newembed], components: [buttons] })
 
            data.Upvote++
 
            if (data.DownMembers.includes(i.user.id)) {
                data.Downvote = data.Downvote - 1;
            }
 
            data.UpMembers.push(i.user.id)
            data.DownMembers.pull(i.user.id)
            data.save();
 
        }
 
        if (i.customId === 'down') {
 
            if (i.user.id === data.Owner) return await i.reply({ content: `<:red_cancel:1115100681129431060> You **cannot** downvote your own **suggestion**!`, ephemeral: true });
            if (data.DownMembers.includes(i.user.id)) return await i.reply({ content: `<:red_cancel:1115100681129431060> You have **already** downvoted this **suggestion**`, ephemeral: true});
 
            let upvotes = data.Upvote;
            if (data.UpMembers.includes(i.user.id)) {
                upvotes = upvotes - 1;
            }
 
            const newembed = EmbedBuilder.from(msg.embeds[0]).setFields({ name: `Upvotes`, value: `> **${upvotes}** Votes`, inline: true}, { name: `Downvotes`, value: `> **${data.Downvote + 1}** Votes`, inline: true}, { name: `Original Author`, value: `> <@${data.Owner}>`});
 
            const buttons = new ActionRowBuilder()
            .addComponents(
 
                new ButtonBuilder()
                .setCustomId('up')
                .setEmoji('<:green_thumb_up:1101072896207634553>')
                .setLabel(`${upvotes}`)
                .setStyle(ButtonStyle.Secondary),
 
                new ButtonBuilder()
                .setCustomId('down')
                .setEmoji('<:red_thumb_down:1115100724532084808>')
                .setLabel(`${data.Downvote + 1}`)
                .setStyle(ButtonStyle.Secondary),
 
                new ButtonBuilder()
                .setCustomId('votes')
                .setLabel('Who Voted?')
                .setStyle(ButtonStyle.Secondary)
            )
 
            await i.update({ embeds: [newembed], components: [buttons] })
 
            data.Downvote++
 
            if (data.UpMembers.includes(i.user.id)) {
                data.Upvote = data.Upvote - 1;
            }
 
            data.DownMembers.push(i.user.id);
            data.UpMembers.pull(i.user.id);
            data.save();
 
        }
 
        if (i.customId === 'votes') {
 
            let upvoters = [];
            await data.UpMembers.forEach(async member => {
                upvoters.push(`<@${member}>`)
            })
 
            let downvoters = [];
            await data.DownMembers.forEach(async member => {
                downvoters.push(`<@${member}>`)
            })
 
            const embed = new EmbedBuilder()
            .setTitle('> Suggestion Votes')
            .setColor("#ecb6d3")
            .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1113728702359015434/1113728599195930675.png?width=160&height=160')
            .setTimestamp()
            .addFields({ name: `Upvoters (${upvoters.length})`, value: `> ${upvoters.join(', ').slice(0, 1020) || 'No upvoters'}`, inline: true})
            .addFields({ name: `Downvoters (${downvoters.length})`, value: `> ${downvoters.join(', ').slice(0, 1020) || 'No downvoters'}`, inline: true})
 
            await i.reply({ embeds: [embed], ephemeral: true })
        }
})

// JOIN TO CREATE VOICE CHANNEL CODE //

client.on(Events.VoiceStateUpdate, async (oldState, newState) => {

    try {
        if (newState.member.guild === null) return;
    } catch (err) {
        return;
    }

    if (newState.member.id === '1096048779641237635') return;

    const joindata = await joinschema.findOne({ Guild: newState.member.guild.id });
    const joinchanneldata1 = await joinchannelschema.findOne({ Guild: newState.member.guild.id, User: newState.member.id });

    const voicechannel = newState.channel;

    if (!joindata) return;

    if (!voicechannel) return;
    else {

        if (voicechannel.id === joindata.Channel) {

            if (joinchanneldata1) {
                
                try {

                    const joinfail = new EmbedBuilder()
                    .setColor('#FF8080')
                    .setTimestamp()
                    .setTitle('You tried creating a voice channel but..')
                    .addFields({ name: `Error Occured`, value: `> You already have a voice channel, open at the moment.`})

                    return await newState.member.send({ embeds: [joinfail] });

                } catch (err) {
                    return;
                }

            } else {

                try {

                    const channel = await newState.member.guild.channels.create({
                        type: ChannelType.GuildVoice,
                        name: `${newState.member.user.username} room`,
                        userLimit: joindata.VoiceLimit,
                        parent: joindata.Category
                    })
                    
                    try {
                        await newState.member.voice.setChannel(channel.id);
                    } catch (err) {
                        console.log('Error moving member to the new channel!')
                    }   

                    setTimeout(() => {

                        joinchannelschema.create({
                            Guild: newState.member.guild.id,
                            Channel: channel.id,
                            User: newState.member.id
                        })

                    }, 500)
                    
                } catch (err) {

                    console.log(err)

                    try {

                        const joinfail = new EmbedBuilder()
                        .setColor('#FF8080')
                        .setTimestamp()
                        .setTitle('You tried creating a voice channel but..')
                        .addFields({ name: `Error Occured`, value: `> I could not create your channel, perhaps I am missing some permissions.`})
    
                        await newState.member.send({ embeds: [joinfail] });
    
                    } catch (err) {
                        return;
                    }

                    return;

                }

                try {

                    const joinsuccess = new EmbedBuilder()
                    .setColor('#FF8080')
                    .setTimestamp()
                    .setTitle('Channel Created')
                    .addFields({ name: `Channel Created`, value: `> Your voice channel has been created in **${newState.member.guild.name}**!`})

                    await newState.member.send({ embeds: [joinsuccess] });

                } catch (err) {
                    return;
                }
            }
        }
    }
})

client.on(Events.VoiceStateUpdate, async (oldState, newState) => {

    try {
        if (oldState.member.guild === null) return;
    } catch (err) {
        return;
    }

    if (oldState.member.id === '1096048779641237635') return;

    const leavechanneldata = await joinchannelschema.findOne({ Guild: oldState.member.guild.id, User: oldState.member.id });

    if (!leavechanneldata) return;
    else {

        const voicechannel = await oldState.member.guild.channels.cache.get(leavechanneldata.Channel);

        if (newState.channel === voicechannel) return;

        try {
            await voicechannel.delete()
        } catch (err) {
            return;
        }

        await joinchannelschema.deleteMany({ Guild: oldState.guild.id, User: oldState.member.id })
        try {

            const deletechannel = new EmbedBuilder()
            .setColor('#FF8080')
            .setTimestamp()
            .setTitle('Channel Deleted')
            .addFields({ name: `Channel Deleted`, value: `> Your voice channel has been deleted in **${newState.member.guild.name}**!`})

            await newState.member.send({ embeds: [deletechannel] });

        } catch (err) {
            return;
        } 
    }
})


// AFK System Code //

const afkSchema = require('./Schemas.js/afkSchema');
const { factorialDependencies, leftShift } = require('mathjs');

client.on(Events.MessageCreate, async (message) => {

    if (message.author.bot) return;

    if (message.guild === null) return;
    const afkcheck = await afkSchema.findOne({ Guild: message.guild.id, User: message.author.id});
    if (afkcheck) {
        const nick = afkcheck.Nickname;

        await afkSchema.deleteMany({
            Guild: message.guild.id,
            User: message.author.id
        })
        
        await message.member.setNickname(`${nick}`).catch(Err => {
            return;
        })

        const m1 = await message.reply({ content: `Welcome Back, ${message.author},  I have removed your afk from this server. You can set the afk again by clicking this button </afk set:1096049281514881104>`})
        setTimeout(() => {
            m1.delete();
        }, 4000)
    } else {
        
        const members = message.mentions.users.first();
        if (!members) return;
        const afkData = await afkSchema.findOne({ Guild: message.guild.id, User: members.id })

        if (!afkData) return;

        const member = message.guild.members.cache.get(members.id);
        const msg = afkData.Message;

        if (message.content.includes(members)) {
            const m = await message.reply({ content: `${member.user.tag} is currently AFK! Don't mention them at this time.\n> Reason: ${msg}`});
            setTimeout(() => {
                m.delete();
                message.delete();
            }, 4000)
        }
    }
})

//Ghost Ping
const ghostSchema = require ('./Schemas.js/ghostpingSchema');
const numSchema = require('./Schemas.js/ghostNum');

client.on(Events.MessageDelete, async message => {
    
    const Data= await ghostSchema.findOne({Guild: message.guild.id});
    if (!Data) return;

    if (!message.author) return;
    if (message.author.bot) return;
    if (!message.author.id === client.user.id) return;
    if (message.author === message.mentions.users.first()) return;

    if (message.mentions.users.first() || message.type === MessageType.reply) {

        let number;
        let time = 15;

        const data = numSchema.findOne({Guild: message.guild.id, User: message.author.id});
        if (!data) {
            await numSchema.create({
                Guild: message.guild.id,
                User: message.author.id,
                Number: 1
            })
            
            number = 1;
              } else {
                data.Number += 1;

                number = data.Number;
        }

        if (number == 2) time =60;
        if (number >= 3) time = 500;

        const embed = new EmbedBuilder()
        .setColor('Green')
        .setTimestamp()
        .setTitle('Ghost Ping Detected')
        .setDescription(`${message.author}, you cannot ghost ping members in this server!`)

        const member = message.member;
        await message.channel.send({ embeds: [embed]});

        if (message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return ;
        } else {
            await member.timeout(time * 1000, 'Ghost pinging');
            await member.send ({content: `> <:sadge:1115100726012694558> You have been timed out in ${message.guild.name} for ${time} seconds due to ghost ping members`}).catch(err => {
                return;
            })
    }
  }
})


// Verification System

const capschema = require('./Schemas.js/verify');
const verifyusers = require('./Schemas.js/verifyusers');
 
client.on(Events.InteractionCreate, async interaction => {
 
    if (interaction.guild === null) return;
 
    const verifydata = await capschema.findOne({ Guild: interaction.guild.id });
    const verifyusersdata = await verifyusers.findOne({ Guild: interaction.guild.id, User: interaction.user.id });
 
    if (interaction.customId === 'verify') {
 
        if (!verifydata) return await interaction.reply({ content: `<:green_check:1115100686682706042> The **verification system** has been disabled in this server!`, ephemeral: true});
 
        if (verifydata.Verified.includes(interaction.user.id)) return await interaction.reply({ content: 'You have **already** been verified!', ephemeral: true})
        else {
 
            let letter = ['0','1','2','3','4','5','6','7','8','9','a','A','b','B','c','C','d','D','e','E','f','F','g','G','h','H','i','I','j','J','f','F','l','L','m','M','n','N','o','O','p','P','q','Q','r','R','s','S','t','T','u','U','v','V','w','W','x','X','y','Y','z','Z',]
            let result = Math.floor(Math.random() * letter.length);
            let result2 = Math.floor(Math.random() * letter.length);
            let result3 = Math.floor(Math.random() * letter.length);
            let result4 = Math.floor(Math.random() * letter.length);
            let result5 = Math.floor(Math.random() * letter.length);
 
            const cap = letter[result] + letter[result2] + letter[result3] + letter[result4] + letter[result5];
            console.log(cap)
 
            const captcha = new CaptchaGenerator()
            .setDimension(150, 450)
            .setCaptcha({ text: `${cap}`, size: 60, color: "red"})
            .setDecoy({ opacity: 0.5 })
            .setTrace({ color: "red" })
 
            const buffer = captcha.generateSync();
 
            const verifyattachment = new AttachmentBuilder(buffer, { name: `captcha.png`});
 
            const verifyembed = new EmbedBuilder()
            .setColor('#D7F2CE')
            .setAuthor({ name: `✅ Captcha Verification`})
            .setTimestamp()
            .setImage('attachment://captcha.png')
            .setTitle('Verification Step: Captcha')
            .addFields({ name: `Verify`, value: '> Please use the button bellow to submit your captcha!'})
 
            const verifybutton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel('✅ Enter Captcha')
                .setStyle(ButtonStyle.Success)
                .setCustomId('captchaenter')
            )
 
            const vermodal = new ModalBuilder()
            .setTitle('Verification')
            .setCustomId('vermodal')
 
            const answer = new TextInputBuilder()
            .setCustomId('answer')
            .setRequired(true)
            .setLabel('Please sumbit your Captcha code')
            .setPlaceholder('Your captcha code')
            .setStyle(TextInputStyle.Short)
 
            const vermodalrow = new ActionRowBuilder().addComponents(answer);
            vermodal.addComponents(vermodalrow);
 
            const vermsg = await interaction.reply({ embeds: [verifyembed], components: [verifybutton], ephemeral: true, files: [verifyattachment] });
 
            const vercollector = vermsg.createMessageComponentCollector();
 
            vercollector.on('collect', async i => {
 
                if (i.customId === 'captchaenter') {
                    i.showModal(vermodal);
                }
 
            })
 
            if (verifyusersdata) {
 
                await verifyusers.deleteMany({
                    Guild: interaction.guild.id,
                    User: interaction.user.id
                })
 
                await verifyusers.create ({
                    Guild: interaction.guild.id,
                    User: interaction.user.id,
                    Key: cap
                })
 
            } else {
 
                await verifyusers.create ({
                    Guild: interaction.guild.id,
                    User: interaction.user.id,
                    Key: cap
                })
 
            }
        } 
    }
})
 
client.on(Events.InteractionCreate, async interaction => {
 
    if (!interaction.isModalSubmit()) return;
 
    if (interaction.customId === 'vermodal') {
 
        const userverdata = await verifyusers.findOne({ Guild: interaction.guild.id, User: interaction.user.id });
        const verificationdata = await capschema.findOne({ Guild: interaction.guild.id });
 
        if (verificationdata.Verified.includes(interaction.user.id)) return await interaction.reply({ content: `You have **already** verified within this server!`, ephemeral: true});
 
        const modalanswer = interaction.fields.getTextInputValue('answer');
        if (modalanswer === userverdata.Key) {
 
            const verrole = await interaction.guild.roles.cache.get(verificationdata.Role);
 
            try {
                await interaction.member.roles.add(verrole);
            } catch (err) {
                return await interaction.reply({ content: `There was an **issue** giving you the **<@&${verificationdata.Role}>** role, try again later!`, ephemeral: true})
            }
 
            await interaction.reply({ content: 'You have been **verified!**', ephemeral: true});
            await capschema.updateOne({ Guild: interaction.guild.id }, { $push: { Verified: interaction.user.id }});
 
        } else {
            await interaction.reply({ content: `**Oops!** It looks like you **didn't** enter the valid **captcha code**!`, ephemeral: true})
        }
    }
})  

// Leveling System Code //
//XP System
const levelSchema = require("./Schemas.js/level");
const levelChannel = require("./Schemas.js/xpChannel");
const { emitWarning } = require('process');
client.on(Events.MessageCreate, async (message) => {
    
    const { guild, author } = message;

    if (!guild || author.bot) return;

    levelSchema.findOne({
        Guild: guild.id,
        User: author.id
    }, async (err, data) => {

        if (err) throw err;

        if (!data) {
            levelSchema.create({
                Guild: guild.id,
                User: author.id,
                XP: 0,
                Level: 0
            })
        }
    })

    const dataChannel = await levelChannel.findOne({ Guild: message.guild.id });

    let channel = " ";

    if (dataChannel) {
        const i = await client.channels.cache.get(`${dataChannel.Channel}`);
        channel = i
    } else {
        channel = message.channel
    }

    const give = 5;

    const data = await levelSchema.findOne({ Guild: guild.id, User: author.id});

    if (!data) return;

    const requiredXP = data.Level * data.Level * 10 + 10;

    if (data.XP + give >= requiredXP) {
        data.XP += give;
        data.Level +=1;
        await data.save();

        if (!channel) return;

        const embed = new EmbedBuilder()
        .setColor("#C0C2E2")
        .setDescription(`${author} you have reached **Level ${data.Level}**!`)
        .addFields(
            {name: "XP:", value: `${data.XP}`, inline: true},
            {name: "Level:", value: `${data.Level}`, inline: true}
        )
        .setTimestamp()
        .setThumbnail(author.displayAvatarURL())
        .setFooter({ text: `🎉 Congrats on leveled up! 🎉`})

        channel.send({ embeds: [embed] }).then(msg => {
            setTimeout(() => msg.delete(), 5000)
        });

        if (dataChannel) {
            channel.send({ embeds: [embed], content: `<@${message.author.id}>`, ephemeral: true });
        } else {
            channel.send({ embeds: [embed] }).then(msg => {
                setTimeout(() => msg.delete(), 5000)
            });
        }
    } else {
        data.XP += give;
        data.save();
    }
})


// Advanced Help Menu //

client.on(Events.InteractionCreate, async (interaction, err) => {

    const helprow2 = new ActionRowBuilder()
        .addComponents(

            new StringSelectMenuBuilder()
            .setMinValues(1)
            .setMaxValues(1)
            .setCustomId('selecthelp')
            .setPlaceholder('Select a menu')
            .addOptions(
                {
                    label: 'Recently Updates',
                    description: 'Get to know Zenith Recently Updates',
                    emoji: '<:news:1115100706798567424>',
                    value: 'updates',
                },

                {
                    label: 'Security Command',
                    description: 'Displays Zenith\'s security commands',
                    emoji: '<:security:1115100721340227584>',
                    value: 'security'
                },

                {
                    label: 'Economy Command',
                    description: 'Displays Zenith\'s economy commands',
                    emoji: '<:economy:1115100682391912538>',
                    value: 'economy'
                },

                {
                    label: 'Information Command',
                    description: 'Displays Zenith\'s Information commands',
                    emoji: '<:information:1115100697243955302>',
                    value: 'information',
                },

                {
                    label: 'Leveling Command',
                    description: 'Displays Zenith\'s Leveling commands',
                    emoji: '<:Ranking:1115100694161133618>',
                    value: 'leveling',
                },

                {
                    label: 'Misc Command',
                    description: 'Displays Zenith\'s Misc commands',
                    emoji: '<:gamer:1115100738033565770>',
                    value: 'misc',
                },

                {
                    label: 'Minigame Command',
                    description: 'Displays Zenith\'s Misc commands',
                    emoji: '<:minigames:1115100688930832455>',
                    value: 'game',
                },

                {
                    label: 'Moderation Command',
                    description: 'Displays Zenith\'s Moderation commands',
                    emoji: '<:automod:1115100735751856219>',
                    value: 'moderation',
                },

                {
                    label: 'Music Command',
                    description: 'Displays Zenith\'s Music commands',
                    emoji: '<:song:1115100696048574584>',
                    value: 'music',
                },
                {
                    label: 'Utility Command',
                    description: 'Displays Zenith\'s Utility/Settings commands',
                    emoji: '<:settings:1115100699307560980>',
                    value: 'utility',
                },

                {
                    label: 'Setting Command',
                    description: 'Displays Zenith\'s Utility/Settings commands',
                    emoji: '<:D_Setting:1115100713798864917>',
                    value: 'setting',
                },

                {
                    label: 'Giveaway Command',
                    description: 'Displays Zenith\'s Giveaway commands',
                    emoji: '<:giveaway_icon:1115100718311948338>',
                    value: 'giveaway',
                },
            ),
        );

    if (!interaction.isStringSelectMenu()) return;
    if (interaction.customId === 'selecthelp') {
        let choices = "";

        const centerembed = new EmbedBuilder()
        .setColor("#FCDABE")
        .setAuthor({ name: `Zenith Help Menu - Page 1` })
        .setFooter({ text: `Thanks for using Zenith`})
        .addFields({ name: '__Updates__', value: ' - Added ModMail System on 1st May 2023\n - Added Giveaway System & member-chart picture command on 6th May 2023\n Added Suggestion System, ticket system & reminder system on 14th May 2023'})
        .setTimestamp()

        interaction.values.forEach(async (value) => {
            choices += `${value}`;

            if (value === 'updates') {

                setTimeout(() => {
                    interaction.update({ embeds: [centerembed] }).catch(err);
                }, 100)

            }

            if (value === 'security') {

                setTimeout(() => {
                    const security = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Security Command [15 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 2` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111281431382077560/1102188173657907330.png?width=151&height=160')
                    .addFields({ name: '</verify setup:1096832209937248326>', value: '<:replyL:1115100715002634240> Setup a Captcha verification gateway' })
                    .addFields({ name: '</verify disable:1096832209937248326>', value: '<:replyL:1115100715002634240> Disable the Captcha verification' })
                    .addFields({ name: '</anti-ghostping setup:1096067340380147722>', value: '<:replyL:1115100715002634240> Setup Anti Ghost Ping System. If someone ghost ping you, they will get 15 seconds timeout' })
                    .addFields({ name: '</anti-ghostping disable:1096067340380147722>', value: '<:replyL:1115100715002634240> Disable ghost ping system in your server' })
                    .addFields({ name: '</anti-ghostping number-reset:1096067340380147722>', value: '<:replyL:1115100715002634240> Reset the user\'s amount of ghost ping' })
                    .addFields({ name: '</automod mention-spam:1099592178600267806>', value: '<:replyL:1115100715002634240> If someone ping members until a limit, their message will get block' })
                    .addFields({ name: '</automod flagged-words:1099592178600267806>', value: '<:replyL:1115100715002634240> If someone type any slurs words, their message will get block' })
                    .addFields({ name: '</automod keyword:1099592178600267806>', value: '<:replyL:1115100715002634240> Create a word, if members type, their message will get blocked' })
                    .addFields({ name: '</automod spam-messages:1099592178600267806>', value: '<:replyL:1115100715002634240> If someone spam until a limit, their message will get block' })
                    .addFields({ name: '</anti-link setup:1107114170052268052>', value: '<:replyL:1115100715002634240> Setup anti-link system in your server' })
                    .addFields({ name: '</anti-link check:1107114170052268052>', value: '<:replyL:1115100715002634240> Check the status of the anti-link system' })
                    .addFields({ name: '</anti-link disable:1107114170052268052>', value: '<:replyL:1115100715002634240> Disable anti-link system in your server' })
                    .addFields({ name: '</anti-link edit:1107114170052268052>', value: '<:replyL:1115100715002634240> Edit anti-link system' })
                    .setTimestamp();

                    interaction.update({ embeds: [security] }).catch(err);
                }, 100)
            }

            if (value === 'economy') {

                setTimeout(() => {
                    const economy = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Economy Command [8 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 3` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111281305288708176/1102196662920806490.png?width=160&height=160')
                    .addFields({ name: '</daily:1100073286014074950>', value: '<:replyL:1115100715002634240> Claim Your Daily Coins' })
                    .addFields({ name: '</beg:1100070871231627387>', value: 'Beg for some coins' })
                    .addFields({ name: '</balance:1100071037904887898>', value: '<:replyL:1115100715002634240> Check your account balance' })
                    .addFields({ name: '</deposit:1100073286014074951>', value: '<:replyL:1115100715002634240> Deposit your money from your wallet to bank. Type `all` to deposit all' })
                    .addFields({ name: '</withdraw:1100073286014074952>', value: '<:replyL:1115100715002634240> Withdraw your money from bank to wallet. Type `all` to withdraw all' })
                    .addFields({ name: '</economy:1100070871231627388>', value: '<:replyL:1115100715002634240> Create your economy account' })
                    .addFields({ name: '</reset all-currency:1100075430981140582>', value: '<:replyL:1115100715002634240> reset all server member\'s currency' })
                    .addFields({ name: '</reset currency:1100075430981140582>', value: '<:replyL:1115100715002634240> reset someone\'s currency' })
                    .addFields({ name: '</rob:1123519230587973743>', value: '<:replyL:1115100715002634240> rob someone\'s currency' })
                    .setTimestamp();

                    interaction.update({ embeds: [economy] }).catch(err);
                }, 100)
            }

            if (value === 'giveaway') {

                setTimeout(() => {
                    const giveaway = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Giveaway Command [4 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 11` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111281187118387302/1104343813633343508.png?width=160&height=160')
                    .addFields({ name: '</giveaway start:1104339669669396561>', value: '<:replyL:1115100715002634240> Start a new giveaway in your server using Zenith' })
                    .addFields({ name: '</giveaway edit:1104339669669396561>', value: '<:replyL:1115100715002634240> Edit the giveaway that currently hosting' })
                    .addFields({ name: '</giveaway end:1104339669669396561>', value: '<:replyL:1115100715002634240> End the giveaway that currently ongoing' })
                    .addFields({ name: '</giveaway reroll:1104339669669396561>', value: '<:replyL:1115100715002634240> Reroll the ended giveaway' })
                    .setTimestamp();

                    interaction.update({ embeds: [giveaway] }).catch(err);
                }, 100)
            }

            if (value === 'information') {

                setTimeout(() => {
                    const information = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Information Command [11 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 4` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111281052787413072/1102204413315125329.png?width=160&height=160')
                    .addFields({ name: '</feedback:1100974129710116864>', value: '<:replyL:1115100715002634240> Opens an application in which you can share feedback on Zenith Bot with the creator, Zenith.' })
                    .addFields({ name: '</avatar get:1099638359854436423>', value: '<:replyL:1115100715002634240>  Get user\'s avatar' })
                    .addFields({ name: '</avatar pixelate:1099638359854436423>', value: '<:replyL:1115100715002634240> Get user\'s avatar with pixelate' })
                    .addFields({ name: '</bot help:1100634582329597972>', value: '<:replyL:1115100715002634240> Zenith\'s Help Menu' })
                    .addFields({ name: '</botinfo:1100627018040750162>', value: '<:replyL:1115100715002634240> Zenith\'s Bot Information' })
                    .addFields({ name: '</bot invite:1100634582329597972>', value: '<:replyL:1115100715002634240> Gets the bot invite and server invite link' })
                    .addFields({ name: '</ping:1099644195913871490>', value: '<:replyL:1115100715002634240> Zenith\'s ping information' })
                    .addFields({ name: '</serverinfo:1097112636879015960>', value: '<:replyL:1115100715002634240> Your server information' })
                    .addFields({ name: '</mc-info:1099909646384365598>', value: '<:replyL:1115100715002634240> Show a minecraft server Information' })
                    .addFields({ name: '</userinfo:1098446293065543783>', value: '<:replyL:1115100715002634240> A user information' })
                    .addFields({ name: '</membercount-chart:1113484015454916659>', value: '<:replyL:1115100715002634240> give you your server member count with chart' })
                    .addFields({ name: '</vote:1124349535863439443>', value: '<:replyL:1115100715002634240> Vote a zenith on top.gg' })
                    .setTimestamp();

                    interaction.update({ embeds: [information] }).catch(err);
                }, 100)
            }

            if (value === 'misc') {

                setTimeout(() => {
                    const misc = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Misc Command [15 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 6` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111280920884936734/1102206148670660789.png?width=160&height=160')
                    .addFields({ name: '</quote:1099898105446535168>', value: '<:replyL:1115100715002634240> Give you random famous quotes' })
                    .addFields({ name: '</advice:1099899476304461915>', value: '<:replyL:1115100715002634240> Get some advice for you' })
                    .addFields({ name: '</ascii:1098642472470585455>', value: '<:replyL:1115100715002634240> Get the text in a special form' })
                    .addFields({ name: '</confess setup:1100057727981604965>', value: '<:replyL:1115100715002634240>  Setup Confess System' })
                    .addFields({ name: '</confess send:1100057727981604965>', value: '<:replyL:1115100715002634240> Send a message to another one in a private way' })
                    .addFields({ name: '</confess disable:1100057727981604965>', value: '<:replyL:1115100715002634240> Disable the confess system' })
                    .addFields({ name: '</dice:1100684464138493973>', value: '<:replyL:1115100715002634240> Dice system' })
                    .addFields({ name: '</rickroll:1100081340055027794>', value: '<:replyL:1115100715002634240> give you a rickroll link, never gonna give you up, never gonna let you down!' })
                    .addFields({ name: '</spoof:1100308237082968075>', value: '<:replyL:1115100715002634240> generate a fake message using your avatar and name' })
                    .addFields({ name: '</time:1100045795283177523>', value: '<:replyL:1115100715002634240> your country/state time now' })
                    .setTimestamp();

                    interaction.update({ embeds: [misc] }).catch(err);
                }, 100)
            }

            if (value === 'game') {

                setTimeout(() => {
                    const game = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Minigame Command [9 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 6` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111280805260562512/1102226731047329812.png?width=160&height=160')
                    .addFields({ name: '</minigame 2048:1099733186856095884>', value: '<:replyL:1115100715002634240> Play 2048 game in discord' })
                    .addFields({ name: '</minigame 8ball:1099733186856095884>', value: '<:replyL:1115100715002634240> Asks 8ball a specified question.' })
                    .addFields({ name: '</minigame hangman:1099733186856095884>', value: '<:replyL:1115100715002634240> Play a hangman game in discord' })
                    .addFields({ name: '</minigame minesweeper:1099733186856095884>', value: '<:replyL:1115100715002634240>   Start a game of explosive minesweeper' })
                    .addFields({ name: '</minigame snake:1099733186856095884>', value: '<:replyL:1115100715002634240>  play a snake game xD' })
                    .addFields({ name: '</minigame tic-tac-toe:1099733186856095884>', value: '<:replyL:1115100715002634240> play tic-tac-toe in discord with your friends' })
                    .addFields({ name: '</minigame wordle:1099733186856095884>', value: '<:replyL:1115100715002634240> play a wordle game' })
                    .addFields({ name: '</minigame would-you-rather:1099733186856095884>', value: '<:replyL:1115100715002634240> choose 2 option, which one you would wanna do!' })
                    .setTimestamp();

                    interaction.update({ embeds: [game] }).catch(err);
                }, 100)
            }

            if (value === 'moderation') {

                setTimeout(() => {
                    const moderation = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Moderation Command [16 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 7` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111280645113659522/1102233639850365081.png?width=160&height=126')
                    .addFields({ name: '</purge:1098181864289742858>', value: '<:replyL:1115100715002634240> Bulk deletes given amount of messages. Limit is 100 due to api limitations.' })
                    .addFields({ name: '</ban:1096049281514881106>', value: '<:replyL:1115100715002634240> Bans the user specified for specified reason.' })
                    .addFields({ name: '</unban:1096049281514881108>', value: '<:replyL:1115100715002634240> Unbans the user specified for specified reason.' })
                    .addFields({ name: '</mass-unban:1100297531470127275>', value: '<:replyL:1115100715002634240> Unban all the server members' })
                    .addFields({ name: '</warn user:1098138880437391370>', value: '<:replyL:1115100715002634240> Warns specified User for specified reason.' })
                    .addFields({ name: '</warn show:1098138880437391370>', value: '<:replyL:1115100715002634240> Displays your current warnings' })
                    .addFields({ name: '</warn remove:1098138880437391370>', value: '<:replyL:1115100715002634240> Resets specified User\'s warnings back to default.' })
                    .addFields({ name: '</kick:1100299603556970506>', value: '<:replyL:1115100715002634240> Kicks specified user for specified reason.' })
                    .addFields({ name: '<:update1:1114084514403188766><:update2:1114084646859329566> </timeout:1096049281514881107>', value: '<:replyL:1115100715002634240> Times out specified user for specified reason for specified amount of time.' })
                    .addFields({ name: '<:update1:1114084514403188766><:update2:1114084646859329566> </untimeout:1102441621649375270>', value: '<:replyL:1115100715002634240> Un-timesout specified user for specified reason.' })
                    .addFields({ name: '</lockdown commit:1100328813105250415>', value: '<:replyL:1115100715002634240> lock down the entire server' })
                    .addFields({ name: '</lockdown unlock:1100328813105250415>', value: '<:replyL:1115100715002634240> unlock the entire server' })
                    .addFields({ name: '</lockdown blacklist-add:1100328813105250415>', value: '<:replyL:1115100715002634240> add a channel to the blacklisted list' })
                    .addFields({ name: '</lockdown blacklist-remove:1100328813105250415>', value: '<:replyL:1115100715002634240> unblacklisted the lockdown channel' })
                    .addFields({ name: '</setmodlog:1107173594603204629>', value: '<:replyL:1115100715002634240> Setup modlog in your channel' })
                    .addFields({ name: '</disablemodlog:1107173594603204628>', value: '<:replyL:1115100715002634240> Disable modlog in your server' })
                    .setTimestamp();

                    interaction.update({ embeds: [moderation] }).catch(err);
                }, 100)
            }

            if (value === 'music') {

                setTimeout(() => {
                    const music = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Music Command [2 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 8` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111280422572265512/1102237310197698700.png?width=160&height=160')
                    .addFields({ name: '</spotify:1102236988872069150>', value: '<:replyL:1115100715002634240> will give u a banner, if you listening to spotify' })
                    .addFields({ name: '</radio:1111322475788255272>', value: '<:replyL:1115100715002634240> a 24/7 radio system for your server!' }) 
                    .setTimestamp();

                    interaction.update({ embeds: [music] }).catch(err);
                }, 100)
            }

            if (value === 'setting') {

                setTimeout(() => {
                    const setting = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Setting Command [14 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 10` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111280254212915210/1102511190489432076.png?width=160&height=160')
                    .addFields({ name: '</auto-role set:1100337395196506112>', value: '<:replyL:1115100715002634240>  Gives role when user join' })
                    .addFields({ name: '</auto-role remove:1100337395196506112>', value: '<:replyL:1115100715002634240>  Removes auto-role in your server' })
                    .addFields({ name: '</serverstats total-set:1100328813105250416>', value: '<:replyL:1115100715002634240> choose a voice channel to place total member serverstats' })
                    .addFields({ name: '</serverstats total-remove:1100328813105250416>', value: '<:replyL:1115100715002634240> remove total member serverstats' })
                    .addFields({ name: '</serverstats bot-set:1100328813105250416>', value: '<:replyL:1115100715002634240> choose a voice channel to place total bots serverstats' })
                    .addFields({ name: '</serverstats bot-remove:1100328813105250416>', value: '<:replyL:1115100715002634240> remove bot serverstats' })
                    .addFields({ name: '</join-to-create setup:1100998745669259345>', value: '<:replyL:1115100715002634240> setup system in your server' })
                    .addFields({ name: '</join-to-create disable:1100998745669259345>', value: '<:replyL:1115100715002634240> disabe jtc system in your server' })
                    .addFields({ name: '</modmail setup:1102596313591316520>', value: '<:replyL:1115100715002634240> Setup modmail system in your server & bot' })
                    .addFields({ name: '</modmail close:1102596313591316520>', value: '<:replyL:1115100715002634240> Close the modmail ticket' })
                    .addFields({ name: '</modmail disable:1102596313591316520>', value: '<:replyL:1115100715002634240> Disable modmail system in your server' })
                    .addFields({ name: '</suggestion-send:1113730163117662258>', value: '<:replyL:1115100715002634240> setup suggestion system in a channel in your server' })
                    .addFields({ name: '</emoji-enlarger:1099900212488712273>', value: '<:replyL:1115100715002634240> enlarges the specified emoji. Does not support default emojies.' })
                    .addFields({ name: '</emoji-find:1123437553438179380>', value: '<:replyL:1115100715002634240> find a emoji that you want' })
                    .setTimestamp();

                    interaction.update({ embeds: [setting] }).catch(err);
                }, 100)
            }

            if (value === 'utility') {

                setTimeout(() => {
                    const utility = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Utility Command [19 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 9` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111280013036224532/1102238840510492852.png?width=160&height=160')
                    .addFields({ name: '</steal:1100296385598857296>', value: '<:replyL:1115100715002634240> specified emoji to your server.Using nitro will ease this process can\'t ne procedeed.' })
                    .addFields({ name: '</add emoji:1100297899860054056>', value: '<:replyL:1115100715002634240> add emoji' })
                    .addFields({ name: '</add sticker:1100297899860054056>', value: '<:replyL:1115100715002634240> add a sticker' })
                    .addFields({ name: '</role members:1100308237082968077>', value: '<:replyL:1115100715002634240> Lists specified role\'s members' })
                    .addFields({ name: '</role add:1100308237082968077>', value: '<:replyL:1115100715002634240> Adds specified role to specified user.' })
                    .addFields({ name: '</role delete:1100308237082968077>', value: '<:replyL:1115100715002634240> Deletes specified role.' })
                    .addFields({ name: '</role remove:1100308237082968077>', value: '<:replyL:1115100715002634240>  Removes specified role from specified user' })
                    .addFields({ name: '</role-info:1100308237082968076>', value: '<:replyL:1115100715002634240>  Check the role information' })
                    .addFields({ name: '</serverrole all:1106893283671687222>', value: '<:replyL:1115100715002634240>  Gives everyone a role' })
                    .addFields({ name: '</reminder set:1111274236959539200>', value: '<:replyL:1115100715002634240> Set your personla reminder' })
                    .addFields({ name: '</reminder cancel:1111274236959539200>', value: '<:replyL:1115100715002634240> Cancel a single reminder that you set before.' })
                    .addFields({ name: '</reminder cancel-all:1111274236959539200>', value: '<:replyL:1115100715002634240> Cancel all your reminder' })
                    .addFields({ name: '</ask-gpt:1100374089564164187>', value: '<:replyL:1115100715002634240>  you can ask chat-gpt something that you want' })
                    .addFields({ name: '</translate text:1107122806463942806>', value: '<:replyL:1115100715002634240>  Translate another language to another language' })
                    .addFields({ name: '</backup create:1115100118065098762>', value: '<:replyL:1115100715002634240>  Create a server template backup for your server' })
                    .addFields({ name: '</backup load:1115100118065098762>', value: '<:replyL:1115100715002634240>  Load the server template backup in another server' })
                    .addFields({ name: '</youtube-notifier add:1124349535863439446>', value: '<:replyL:1115100715002634240>  Youtube social connector, add your youtube channel into it' })
                    .addFields({ name: '</youtube-notifier remove:1124349535863439446>', value: '<:replyL:1115100715002634240>  Youtube social connector, remove your youtube channel into it' })
                    .setTimestamp();

                    interaction.update({ embeds: [utility] }).catch(err);
                }, 100)
            }

            if (value === 'leveling') {

                setTimeout(() => {
                    const leveling = new EmbedBuilder()
                    .setColor("#FCDABE")
                    .setTitle('Leveling & Ranking Command [8 commands]')
                    .setAuthor({ name: `Zenith Help Menu - Page 5` })
                    .setFooter({ text: `Thanks for using Zenith` })
                    .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1111279845641564303/1102237990065021008.png?width=60&height=60')
                    .addFields({ name: '</rank:1100078055424282654>', value: '<:replyL:1115100715002634240> Display someone\'s ranking' })
                    .addFields({ name: '</leveling enable:1100075430981140581>', value: '<:replyL:1115100715002634240> Enable leveling in your server' })
                    .addFields({ name: '</leveling disable:1100075430981140581>', value: '<:replyL:1115100715002634240> disable leveling in your server' })
                    .addFields({ name: '</leveling role-multiplier:1100075430981140581>', value: '<:replyL:1115100715002634240> Enable levels role' })
                    .addFields({ name: '</leveling disable-multiplier:1100075430981140581>', value: '<:replyL:1115100715002634240> Disable levels role' })
                    .addFields({ name: '</leaderboard:1100075430981140580>', value: '<:replyL:1115100715002634240> rank leaderboard' })
                    .addFields({ name: '</reset all-xp:1100075430981140582>', value: '<:replyL:1115100715002634240> reset all server members XP' })
                    .addFields({ name: '</reset xp:1100075430981140582>', value: '<:replyL:1115100715002634240>  reset a user\'s xp' })
                    .setTimestamp();

                    interaction.update({ embeds: [leveling] }).catch(err);
                }, 100)
            }
         }
        )}

// Member Voice Channels Code //

client.on(Events.GuildMemberAdd, async (member, err) => {

    if (member.guild === null) return;
    const voicedata = await voiceschema.findOne({ Guild: member.guild.id });

    if (!voicedata) return;
    else {

        const totalvoicechannel = member.guild.channels.cache.get(voicedata.TotalChannel);
        if (!totalvoicechannel || totalvoicechannel === null) return;
        const totalmembers = member.guild.memberCount;

        totalvoicechannel.setName(`Total Members: ${totalmembers}`).catch(err);

    }
})

client.on(Events.GuildMemberRemove, async (member, err) => {

    if (member.guild === null) return;
    const voicedata1 = await voiceschema.findOne({ Guild: member.guild.id });

    if (!voicedata1) return;
    else {

        const totalvoicechannel1 = member.guild.channels.cache.get(voicedata1.TotalChannel);
        if (!totalvoicechannel1 || totalvoicechannel1 === null) return;
        const totalmembers1 = member.guild.memberCount;

        totalvoicechannel1.setName(`Total Members: ${totalmembers1}`).catch(err);
    
    }
})

// Total Bots Voice Channel Code //

client.on(Events.GuildMemberAdd, async (member, err) => {

    if (member.guild === null) return;
    const botdata = await botschema.findOne({ Guild: member.guild.id });

    if (!botdata) return;
    else {

        const botvoicechannel = member.guild.channels.cache.get(botdata.BotChannel);
        if (!botvoicechannel || botvoicechannel === null) return;
        const botslist = member.guild.members.cache.filter(member => member.user.bot).size;

        botvoicechannel.setName(`Total Bots: ${botslist}`).catch(err);

    }
})

client.on(Events.GuildMemberRemove, async (member, err) => {

    if (member.guild === null) return;
    const botdata1 = await botschema.findOne({ Guild: member.guild.id });

    if (!botdata1) return;
    else {

        const botvoicechannel1 = member.guild.channels.cache.get(botdata1.BotChannel);
        if (!botvoicechannel1 || botvoicechannel1 === null) return;
        const botslist1 = member.guild.members.cache.filter(member => member.user.bot).size;

        botvoicechannel1.setName(`Total Bots: ${botslist1}`).catch(err);
    
    }
})

// Reminder Command
const reminderSchema = require('./Schemas.js/reminderSchema');
setInterval(async () => {

    const reminders = await reminderSchema.find();
    if (!reminders) return;
    else {

        reminders.forEach( async reminder => {

            if (reminder.Time > Date.now()) return;

            const user = await client.users.fetch(reminder.User);

            user?.send({
                content: `${user}, you asked me to remind you about: \`${reminder.Remind}\``
            }).catch(err => {return;});

            await remindSchema.deleteMany({
                Time: reminder.Time,
                User: user.id,
                Remind: reminder.Remind
            });
            
        })
    }
}, 1000 * 5);
})

// Mod logs //
client.on(Events.ChannelCreate, async (channel) => {
  const guildId = channel.guild.id;
  const modlog = await Modlog.findOne({ guildId });
 
  if (!modlog || !modlog.logChannelId) {
    return; // if there's no log channel set up, return without sending any log message
}
 
  channel.guild.fetchAuditLogs({
    type: AuditLogEvent.ChannelCreate,
  })
    .then(async (audit) => {
      const { executor } = audit.entries.first();
 
      const name = channel.name;
      const id = channel.id;
      let type = channel.type;
 
      if (type == 0) type = 'Text'
      if (type == 2) type = 'Voice'
      if (type == 13) type = 'Stage'
      if (type == 15) type = 'Form'
      if (type == 4) type = 'Announcement'
      if (type == 5) type = 'Category'
 
      const mChannel = await channel.guild.channels.cache.get(modlog.logChannelId);
 
      const embed = new EmbedBuilder()
        .setColor('#FF8080')
        .setTitle('Channel Created')
        .setDescription(`Channel Name: ${name} (<#${id}>)\n<:arrow:1115100703069831270> Channel Type: ${type}\n<:arrow:1115100703069831270> Channel ID: ${id}`)
        .addFields({ name: '<:user:1115100701920612473> Created By', value: `${executor.tag}`})
        .setTimestamp()
        .setFooter({ text: 'ModLog by Zenith' });
 
    mChannel.send({ embeds: [embed] })
 
    })
})
 
client.on(Events.ChannelDelete, async channel => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = channel.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    channel.guild.fetchAuditLogs({
        type: AuditLogEvent.ChannelDelete,
    })
    .then (async audit => {
        const { executor } = audit.entries.first()
 
        const name = channel.name;
        const id = channel.id;
        let type = channel.type;
 
        if (type == 0) type = 'Text'
        if (type == 2) type = 'Voice'
        if (type == 13) type = 'Stage'
        if (type == 15) type = 'Form'
        if (type == 4) type = 'Announcement'
        if (type == 5) type = 'Category'
 
        const mChannel = await channel.guild.channels.cache.get(modlog.logChannelId);
 
    const embed = new EmbedBuilder()
    .setColor("#FF8080")
    .setTitle("Channel Deleted")
    .setDescription(`Channel Name: ${name}\n<:arrow:1115100703069831270> Channel Type: ${type}\n<:arrow:1115100703069831270> Channel ID: ${id}`)
    .addFields({ name: "<:user:1115100701920612473> Deleted By", value: `${executor.tag}`})
    .setTimestamp()
    .setFooter({ text: "ModLog by Zenith"})
 
    mChannel.send({ embeds: [embed] })
 
     })
})
 
client.on(Events.GuildBanAdd, async member => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = member.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    member.guild.fetchAuditLogs({
        type: AuditLogEvent.GuildBanAdd,
    })
    .then (async audit => {
        const { executor } = audit.entries.first()
 
        const name = member.user.username;
        const id = member.user.id;
 
 
    const mChannel = await member.guild.channels.cache.get(modlog.logChannelId)
 
    const embed = new EmbedBuilder()
    .setColor("#FF8080")
    .setTitle("Member Banned")
    .setDescription(`Member Name: ${name}\n<:arrow:1115100703069831270> Member ID: \`${id}\`\n<:arrow:1115100703069831270> Member: <@${id}>`)
    .addFields({ name: "<:user:1115100701920612473> Banned By", value: `${executor.tag}`})
    .setTimestamp()
    .setFooter({ text: "ModLog by Zenith"})
 
    mChannel.send({ embeds: [embed] })
 
    })
})
 
client.on(Events.GuildBanRemove, async member => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = member.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    member.guild.fetchAuditLogs({
        type: AuditLogEvent.GuildBanRemove,
    })
    .then (async audit => {
        const { executor } = audit.entries.first()
 
        const name = member.user.username;
        const id = member.user.id;
 
 
    const mChannel = await member.guild.channels.cache.get(modlog.logChannelId)
 
    const embed = new EmbedBuilder()
    .setColor("#FF8080")
    .setTitle("Member Unbanned")
    .setDescription(`Member Name: ${name}\n<:arrow:1115100703069831270> Member ID: \`${id}\`\n<:arrow:1115100703069831270> Member: <@${id}>`)
    .addFields({ name: "<:user:1115100701920612473> Unbanned By", value: `${executor.tag}`})
    .setTimestamp()
    .setFooter({ text: "ModLog by Zenith"})
 
    mChannel.send({ embeds: [embed] })
 
    })
})
 
client.on(Events.MessageDelete, async (message) => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = message.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    message.guild.fetchAuditLogs({
        type: AuditLogEvent.MessageDelete,
    })
    .then (async audit => {
        const { executor } = audit.entries.first()
 
        const mes = message.content;
 
        if (!mes) return
 
        const mChannel = await message.guild.channels.cache.get(modlog.logChannelId)
 
        const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Message Delete")
        .setDescription(`Message Content: ${mes}\n<:arrow:1115100703069831270> Message Channel: ${message.channel}`)
        .addFields({ name: "<:user:1115100701920612473> Deleted By", value: `${executor.tag}`})
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith"})
 
        mChannel.send({ embeds: [embed] })
 
    })
})
 
client.on(Events.MessageUpdate, async (message, newMessage) => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = message.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    message.guild.fetchAuditLogs({
        type: AuditLogEvent.MessageUpdate,
    })
    .then (async audit => {
        const { executor } = audit.entries.first()
 
        const mes = message.content;
 
        if (!mes) return
 
    const mChannel = await message.guild.channels.cache.get(modlog.logChannelId)
 
    const embed = new EmbedBuilder()
    .setColor("#FF8080")
    .setTitle("Message Edited")
    .setDescription(`Old Message: ${mes}\n<:arrow:1115100703069831270> New Message: ${newMessage}`)
    .addFields({ name: "<:user:1115100701920612473> Edited By", value: `${executor.tag}`})
    .setTimestamp()
    .setFooter({ text: "ModLog by Zenith"})
 
    mChannel.send({ embeds: [embed] })
 
    })
})
 
client.on(Events.MessageBulkDelete, async messages => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = messages.first().guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    messages.first().guild.fetchAuditLogs({
        type: AuditLogEvent.MessageBulkDelete,
    })
    .then(async audit => {
        const { executor } = audit.entries.first();
 
        const mChannel = await messages.first().guild.channels.cache.get(modlog.logChannelId);
 
        const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Message Bulk Delete")
        .setDescription(`Message Channel: ${messages.first().channel}`)
        .addFields({ name: "<:user:1115100701920612473> Bulk Deleted By", value: `${executor.tag}`})
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith" });
 
        mChannel.send({ embeds: [embed] });
    });
});
 
client.on(Events.GuildRoleCreate, async role => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = role.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    role.guild.fetchAuditLogs({
        type: AuditLogEvent.RoleCreate,
    })
    .then(async audit => {
        const { executor } = audit.entries.first();
 
        const mChannel = await role.guild.channels.cache.get(modlog.logChannelId);
 
        const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Role Created")
        .setDescription(`Role Name: <@&${role.id}>\n<:arrow:1115100703069831270> Role ID: ${role.id}`)
        .addFields({ name: "<:user:1115100701920612473> Role Created By", value: `${executor.tag}`})
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith" });
 
        mChannel.send({ embeds: [embed] });
    });
});
 
 
 
 
client.on(Events.GuildRoleDelete, async role => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = role.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    role.guild.fetchAuditLogs({
        type: AuditLogEvent.RoleDelete,
    })
    .then(async audit => {
        const { executor } = audit.entries.first();
 
        const mChannel = await role.guild.channels.cache.get(modlog.logChannelId);
 
        const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Role Deleted")
        .setDescription(`Role Name: ${role.name}\n<:arrow:1115100703069831270> Role ID: ${role.id}`)
        .addFields({ name: "<:user:1115100701920612473> Role Deleted By", value: `${executor.tag}`})
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith" });
 
        mChannel.send({ embeds: [embed] });
    });
});
 
 
client.on(Events.GuildMemberAdd, async member => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = member.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    const mChannel = await member.guild.channels.cache.get(modlog.logChannelId);
 
    const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Member Joined")
        .setDescription(`Username: ${member.user.username}#${member.user.discriminator}\n<:arrow:1115100703069831270> Member ID: ${member.user.id}\n<:arrow:1115100703069831270> Joined At: ${member.joinedAt.toUTCString()}`)
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith" });
 
    mChannel.send({ embeds: [embed] });
});
 
 
client.on(Events.GuildMemberRemove, async member => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = member.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    const mChannel = await member.guild.channels.cache.get(modlog.logChannelId);
 
    const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Member Left")
        .setDescription(`Username: ${member.user.username}#${member.user.discriminator}\n<:arrow:1115100703069831270> Member ID: ${member.user.id}\n<:arrow:1115100703069831270> Left At: ${new Date().toUTCString()}\n <:arrow:1115100703069831270> Joined At: ${member.joinedAt.toUTCString()}`)
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith" });
 
    mChannel.send({ embeds: [embed] });
});
 
client.on(Events.UserUpdate, async (oldUser, newUser) => {
    if (oldUser.username === newUser.username) {
        return; // if the username hasn't changed, return without sending any log message
    }
 
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = newUser.guildId;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    const mChannel = await newUser.guild.channels.cache.get(modlog.logChannelId);
 
    const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Username Changed")
        .setDescription(`User: ${newUser.username}#${newUser.discriminator}\n<:arrow:1115100703069831270> User ID: ${newUser.id}\n<:arrow:1115100703069831270> Old Username: ${oldUser.username}\n<:arrow:1115100703069831270> New Username: ${newUser.username}`)
        .setTimestamp()
        .setFooter({ text: "ModLog by Zenith" });
 
    mChannel.send({ embeds: [embed] });
});
 
client.on(Events.GuildMemberRemove, async (member) => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = member.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    member.guild.fetchAuditLogs({
        type: AuditLogEvent.MemberKick,
    })
    .then (async audit => {
 
        const { executor } = audit.entries.first();
 
    const mChannel = await member.guild.channels.cache.get(modlog.logChannelId);
 
    const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Member Kicked")
        .setDescription(`**User:** ${member.user.username}#${member.user.discriminator}\n<:arrow:1115100703069831270> User ID: ${member.user.id}`)
        .addFields({ name: "<:user:1115100701920612473> Kicked By", value: `${executor.tag}`})
        .setFooter({ text: "ModLog by Zenith" });
 
    mChannel.send({ embeds: [embed] });
    })
});
 
 
client.on(Events.InviteCreate, async (invite) => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = invite.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    const mChannel = await invite.guild.channels.cache.get(modlog.logChannelId);
 
    const embed = new EmbedBuilder()
        .setColor("#FF8080")
        .setTitle("Invite Created")
        .addFields({ name: "Code", value: `${invite.code}`, inline: true })
        .addFields({ name: "Channel", value: `${invite.channel}`, inline: true })
        .addFields({ name: "Inviter", value: `${invite.inviter}`, inline: true })
        .setTimestamp()
        .setFooter({ text: "MogLog by Zenith" });
 
    mChannel.send({ embeds: [embed] });
});

client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
    const Modlog = require('./Schemas.js/modlog');
 
    const guildId = newMember.guild.id;
    const modlog = await Modlog.findOne({ guildId });
 
    if (!modlog || !modlog.logChannelId) {
        return; // if there's no log channel set up, return without sending any log message
    }
 
    newMember.guild.fetchAuditLogs({
        type: AuditLogEvent.MemberRoleUpdate,
    })
    .then (async audit => {
 
        const { executor } = audit.entries.first();
        const mChannel = await newMember.guild.channels.cache.get(modlog.logChannelId);
 
        if (oldMember.roles.cache.size > newMember.roles.cache.size) {
            const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
            const roleNameArray = removedRoles.map(role => `<@&${role.id}>`);
            const rolesRemovedString = roleNameArray.join(", ");
 
            const embed = new EmbedBuilder()
                .setColor("#FF8080")
                .setTitle("Roles Removed")
                .addFields(
                    { name: "<:arrow:1115100703069831270> User", value: `<@${newMember.id}>`},
                    { name: "<:arrow:1115100703069831270> Roles Removed", value: rolesRemovedString},
                    { name: "<:user:1115100701920612473> Role Removed By", value: `${executor.tag}`}
                )
                .setTimestamp()
                .setFooter({ text: "MogLog by Zenith" });
            mChannel.send({ embeds: [embed] });
        }
    });
});

// MODMAIL CODE //
 
client.on(Events.MessageCreate, async message => {
 
    if (message.guild) return;
    if (message.author.id === client.user.id) return;
 
    const usesdata = await moduses.findOne({ User: message.author.id });
 
    if (!usesdata) {
 
        message.react('👋')
 
        const modselect = new EmbedBuilder()
        .setColor("#ecb6d3")
        .setTimestamp()
        .setTitle('Select a Server')
        .addFields({ name: `Select a Modmail`, value: `> Please submit the Server's ID you are trying to connect to in the modal displayed when \n> pressing the button bellow!`})
        .addFields({ name: `How do I get the server's ID?`, value: `> To get the Server's ID you will have to enable Developer Mode through the Discord settings, then you can get the Server's ID by right \n> clicking the Server's icon and pressing "Copy Server ID".`})
 
        const button = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId('selectmodmail')
            .setLabel('Select your Server')
            .setStyle(ButtonStyle.Secondary)
        )     
 
        const msg = await message.reply({ embeds: [modselect], components: [button] });
        const selectcollector = msg.createMessageComponentCollector();
 
        selectcollector.on('collect', async i => {
 
            if (i.customId === 'selectmodmail') {
 
                const selectmodal = new ModalBuilder()
                .setTitle('Modmail Selector')
                .setCustomId('selectmodmailmodal')
 
                const serverid = new TextInputBuilder()
                .setCustomId('modalserver')
                .setRequired(true)
                .setLabel('What server do you want to connect to?')
                .setPlaceholder('Example: "1098186360893997167"')
                .setStyle(TextInputStyle.Short);
 
                const subject = new TextInputBuilder()
                .setCustomId('subject')
                .setRequired(true)
                .setLabel(`What's the reason for contacting us?`)
                .setPlaceholder(`Example: "I wanted to bake some cookies, but Zenith didn't let me!!!"`)
                .setStyle(TextInputStyle.Paragraph);
 
                const serveridrow = new ActionRowBuilder().addComponents(serverid)
                const subjectrow = new ActionRowBuilder().addComponents(subject)
 
                selectmodal.addComponents(serveridrow, subjectrow)
 
                i.showModal(selectmodal)
 
            }
        })
 
    } else {
 
        if (message.author.bot) return;
 
        const sendchannel = await client.channels.cache.get(usesdata.Channel);
        if (!sendchannel) {
 
            message.react('<<:yellow_warning:1115100685252431962>1101072893837852676>')
            await message.reply('**Oops!** Your **modmail** seems **corrupted**, we have **closed** it for you.')
            return await moduses.deleteMany({ User: usesdata.User });
 
        } else {
 
            const msgembed = new EmbedBuilder()
            .setColor("#ecb6d3")
            .setAuthor({ name: `${message.author.username}`, iconURL: `${message.author.displayAvatarURL()}`})
            .setFooter({ text: `Modmail Message - ${message.author.id}`})
            .setTimestamp()
            .setDescription(`${message.content || `**No message provided.**`}`)
 
            if (message.attachments.size > 0) {
 
                try {
                    msgembed.setImage(`${message.attachments.first()?.url}`);
                } catch (err) {
                    return message.react('<:red_cancel:1115100681129431060>')
                }
 
            }
 
            const user = await sendchannel.guild.members.cache.get(usesdata.User)
            if (!user) {
                message.react('<<:yellow_warning:1115100685252431962>1101072893837852676>')
                message.reply(`<<:yellow_warning:1115100685252431962>1101072893837852676> You have left **${sendchannel.guild.name}**, your **modmail** was **closed**!`)
                sendchannel.send(`<<:yellow_warning:1115100685252431962>1101072893837852676> <@${message.author.id}> left, this **modmail** has been **closed**.`)
                return await moduses.deleteMany({ User: usesdata.User })
            }
 
            try {
 
                await sendchannel.send({ embeds: [msgembed] });
 
            } catch (err) {
                return message.react('<:red_cancel:1115100681129431060>')
            }
 
            message.react('<:green_check:1115100686682706042>')
        }
    }
})
 
client.on(Events.InteractionCreate, async interaction => {
 
    if (!interaction.isModalSubmit()) return;
 
    if (interaction.customId === 'selectmodmailmodal') {
 
        const data = await moduses.findOne({ User: interaction.user.id });
        if (data) return await interaction.reply({ content: `You have **already** opened a **modmail**! \n> Do **/modmail close** to close it.`, ephemeral: true });
        else {
 
            const serverid = interaction.fields.getTextInputValue('modalserver');
            const subject = interaction.fields.getTextInputValue('subject');
 
            const server = await client.guilds.cache.get(serverid);
            if (!server) return await interaction.reply({ content: `**Oops!** It seems like that **server** does not **exist**, or I am **not** in it!`, ephemeral: true });
 
            const executor = await server.members.cache.get(interaction.user.id);
            if (!executor) return await interaction.reply({ content: `You **must** be a member of **${server.name}** in order to **open** a **modmail** there!`, ephemeral: true});
 
            const modmaildata = await modschema.findOne({ Guild: server.id });
            if (!modmaildata) return await interaction.reply({ content: `Specified server has their **modmail** system **disabled**!`, ephemeral: true});
 
            const channel = await server.channels.create({
                name: `modmail-${interaction.user.id}`,
                parent: modmaildata.Category,
 
            }).catch(err => {
                return interaction.reply({ content: `I **couldn't** create your **modmail** in **${server.name}**!`, ephemeral: true});
            })
 
            await channel.permissionOverwrites.create(channel.guild.roles.everyone, { ViewChannel: false });
 
            const embed = new EmbedBuilder()
            .setColor("#ecb6d3")
            .setTimestamp()
            .setTitle(`${interaction.user.username}'s Modmail`)
            .addFields({ name: `Subject`, value: `> ${subject}`})
 
            const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId('deletemodmail')
                .setEmoji('<:red_cancel:1115100681129431060>')
                .setLabel('Delete')
                .setStyle(ButtonStyle.Secondary),
 
                new ButtonBuilder()
                .setCustomId('closemodmail')
                .setEmoji('🔒')
                .setLabel('Close')
                .setStyle(ButtonStyle.Secondary)
            )
 
            await moduses.create({
                Guild: server.id,
                User: interaction.user.id,
                Channel: channel.id
            })
 
            await interaction.reply({ content: `Your **modmail** has been opened in **${server.name}**!`, ephemeral: true});
            const channelmsg = await channel.send({ embeds: [embed], components: [buttons] });
            channelmsg.createMessageComponentCollector();
 
        }
    }
})
 
client.on(Events.InteractionCreate, async interaction => {
 
    if (interaction.customId === 'deletemodmail') {
 
        const closeembed = new EmbedBuilder()
        .setColor("#ecb6d3")
        .setTimestamp()
        .setTitle('Your modmail was Closed')
        .addFields({ name: `Server`, value: `> ${interaction.guild.name}`})
 
        const delchannel = await interaction.guild.channels.cache.get(interaction.channel.id);
        const userdata = await moduses.findOne({ Channel: delchannel.id });
 
        await delchannel.send('<a:loading:1102426967686529065> **Deleting** this **modmail**..')
 
        setTimeout(async () => {
 
            if (userdata) {
 
                const executor = await interaction.guild.members.cache.get(userdata.User)
                if (executor) {
                    await executor.send({ embeds: [closeembed] });
                    await moduses.deleteMany({ User: userdata.User });
                }
 
            }
 
            try {
                await delchannel.delete();
            } catch (err) {
                return;
            }
 
        }, 100)
 
    }
 
    if (interaction.customId === 'closemodmail') {
 
        const closeembed = new EmbedBuilder()
        .setColor("#ecb6d3")
        .setTimestamp()
        .setTitle('Your modmail was Closed')
        .addFields({ name: `Server`, value: `> ${interaction.guild.name}`})
 
        const clchannel = await interaction.guild.channels.cache.get(interaction.channel.id);
        const userdata = await moduses.findOne({ Channel: clchannel.id });
 
        if (!userdata) return await interaction.reply({ content: `🔒 You have **already** closed this **modmail**.`, ephemeral: true})
 
        await interaction.reply('<a:loading:1102426967686529065> **Closing** this **modmail**..')
 
        setTimeout(async () => {
 
            const executor = await interaction.guild.members.cache.get(userdata.User)
            if (executor) {
 
                try {
                    await executor.send({ embeds: [closeembed] });
                } catch (err) {
                    return;
                }
 
            }
 
            interaction.editReply(`🔒 **Closed!** <@${userdata.User}> can **no longer** view this **modmail**, but you can!`)
 
            await moduses.deleteMany({ User: userdata.User });
 
        }, 100)
 
    }
})
 
client.on(Events.MessageCreate, async message => {
 
    if (message.author.bot) return;
    if (!message.guild) return;
 
    const data = await modschema.findOne({ Guild: message.guild.id });
    if (!data) return;
 
    const sendchanneldata = await moduses.findOne({ Channel: message.channel.id });
    if (!sendchanneldata) return;
 
    const sendchannel = await message.guild.channels.cache.get(sendchanneldata.Channel);
    const member = await message.guild.members.cache.get(sendchanneldata.User);
    if (!member) return await message.reply(`<<:yellow_warning:1115100685252431962>1101072893837852676> <@${sendchanneldata.User} is **not** in your **server**!`)
 
    const msgembed = new EmbedBuilder()
    .setColor("#ecb6d3")
    .setAuthor({ name: `${message.author.username}`, iconURL: `${message.author.displayAvatarURL()}`})
    .setFooter({ text: `Modmail Received - ${message.author.id}`})
    .setTimestamp()
    .setDescription(`${message.content || `**No message provided.**`}`)
 
    if (message.attachments.size > 0) {
 
        try {
            msgembed.setImage(`${message.attachments.first()?.url}`);
        } catch (err) {
            return message.react('<:red_cancel:1115100681129431060>')
        }
 
    }
 
    try {
        await member.send({ embeds: [msgembed] });
    } catch (err) {
        message.reply(`<:yellow_warning:1115100685252431962>1101072893837852676>I **couldn't** message **<@${sendchanneldata.User}>**!`)
        return message.react('<:red_cancel:1115100681129431060>')
    }
 
    message.react('<:green_check:1115100686682706042>')
 
})

//server join + server left
client.on(Events.GuildCreate, async guild => {

    const channel = await client.channels.cache.get('1115101169950400512');
    const name = guild.name;
    const memberCount = guild.memberCount;
    const ownerID = guild.ownerId;
    const owner = await client.users.cache.get(ownerID);
    const ownerName = owner.username;

    const embed = new EmbedBuilder()
    .setColor('#B4D5F9')
    .setTitle(`Someone invited Zenith!`)
    .addFields({ name: 'Server Name:', value: `> ${name}`})
    .addFields({ name: 'Server Members:', value: `> ${memberCount}`})
    .addFields({ name: 'Server Owner:', value: `> ${ownerName} (${ownerID})`})
    .addFields({ name: 'Server is created on:', value: `> <t:${parseInt(guild.createdTimestamp / 1000)}:R>`})
    .setTimestamp()
    .setFooter({ text: `Zenith has increased by 1 guild count ${client.guilds.cache.size}`})

    await channel.send({embeds: [embed]});
})

client.on(Events.GuildDelete, async guild => {

    const channel = await client.channels.cache.get('1115101169950400512');
    const name = guild.name;
    const memberCount = guild.memberCount;
    const ownerID = guild.ownerId;
    const owner = await client.users.cache.get(ownerID);
    const ownerName = owner.username;

    const embed = new EmbedBuilder()
    .setColor('#EDC4BC')
    .setTitle(`Someone kicked Zenith!`)
    .addFields({ name: 'Server Name:', value: `> ${name}`})
    .addFields({ name: 'Server Members:', value: `> ${memberCount}`})
    .addFields({ name: 'Server Owner:', value: `> ${ownerName} (${ownerID})`})
    .addFields({ name: 'Server is created on:', value: `> <t:${parseInt(guild.createdTimestamp / 1000)}:R>`})
    .setTimestamp()
    .setFooter({ text: `Zenith has decrease by 1 guild count ${client.guilds.cache.size}`})

    await channel.send({embeds: [embed]});
})

//anti link
const linkSchema = require('./Schemas.js/link');
client.on(Events.MessageCreate, async message => {
 
    if (message.content.startsWith('http') || message.content.startsWith('discord.gg') || message.content.includes('https://') || message.content.includes('http://') || message.content.includes('discord.gg/')) {
 
        const Data = await linkSchema.findOne({ Guild: message.guild.id});
 
        if (!Data) return;
 
        const memberPerms = Data.Perms;
 
        const user = message.author;
        const member = message.guild.members.cache.get(user.id);
 
        if (member.permissions.has(memberPerms)) return;
        else {
            await message.channel.send({ content: `<:red_cancel:1115100681129431060> ${message.author}, you can't send links here!`}).then(msg => {
                setTimeout(() => msg.delete(), 3000)
            })
 
            ;(await message).delete();
        }
    }
})

// command logging
client.on(Events.InteractionCreate, async interaction => {

   if(!interaction) return;

   if(!interaction.isChatInputCommand()) return;

   else {

   const channel = await client.channels.cache.get("1115101112601690183");

   const server = interaction.guild.name

   const user = interaction.user.tag

   const userId = interaction.user.id

 

   const embed = new EmbedBuilder()

   .setColor("Orange")

   .setTitle(`Chat Command Used!`)

   .addFields({ name: `Server Name`, value: `${server}`})

   .addFields({ name: `Chat Command`, value: `${interaction}`})

   .addFields({ name: `User`, value: `${user} (${userId})`})

   .setTimestamp()

   .setFooter({ text: `Chat Command Executed`})

 

   await channel.send({ embeds: [embed] });

 

   }

}) 

client.on(Events.MessageCreate, async message => {
    if (message.author.id !== '751708824796266558') return;
    if (message.content !== '?servers') return;
    
    let owners = [ ];

    await Promise.all(client.guilds.cache.map(async guild => {
        const owner = await guild.members.fetch(guild.ownerId);
        owners.push(`Server Name: ${guild.name} (${guild.id}) | Server Members: ${guild.memberCount} | Onwer: ${owner.user.username} (${guild.ownerId})`)
    }))

    console.log(`Zenith Is In ${client.guilds.cache.size} Servers \n\n ${owners.join('\n ')}`);
    message.reply('**Check** your console!')
})


// Birthday
setInterval(async () => {
 
    const birthdays = await birthdayschema.find();
    if(!birthdays) return;
    else {
        birthdays.forEach(async birthday => {

            let data = await birthdaysetups.findOne({ Guild: birthday.Guild });
            if (!data) return;

            if (birthday.HasRoleSince + 86400000 < Date.now() && birthday.HasRoleSince !== 0 && birthday.HasRoleSince) {

                let guild = await client.guilds.cache.get(birthday.Guild);
                if (!guild) await birthday.delete()
                else {

                    let member = await guild.members.cache.get(birthday.User);
                    if (member) {

                        let birthdayrole = await guild.roles.cache.get(data.Role)

                        if (birthdayrole) {
                            try {
                                member.roles.remove(birthdayrole);
                            } catch {}
                        }
                        
                    }

                    await birthdayschema.updateMany({ User: birthday.User, Guild: birthday.Guild }, { $set: { HasRoleSince: 0 }});

                }
            }
 
            if (birthday.Time > Date.now()) return;

            const channel = await client.channels.cache.get(data.Channel);
            if (!channel) return await birthdayschema.updateMany({ Guild: birthday.Guild, User: user.id, }, { $set: { Time: birthday.Time + 31556926000 }});
 
            const user = await client.users.fetch(birthday.User);
            
            const embed = new EmbedBuilder()
            .setColor("#ecb6d3")
            .setThumbnail('https://media.discordapp.net/attachments/1100630245914202112/1115087346203897936/1600w-mFmsycgF9eM.webp?width=701&height=701')
            .setFooter({ text: `🎉 Happy Birthday to ${user.username || 'Unknown'}`})
            .setTimestamp()
            .setTitle('Happy Birthday!')
            .addFields({ name: 'Noice', value: `Today is ${user}'s Birthday, wish him/her happy birthday and wish him good luck in the future!` })
 
            try {
                channel.send({ embeds: [embed] })
            } catch {}

            await birthdayschema.updateMany({ Guild: birthday.Guild, User: user.id, }, { $set: { Time: birthday.Time + 31556926000 }});

            let guild = await client.guilds.cache.get(birthday.Guild);
            if (!guild) return birthday.delete();
            else {

                let member = await guild.members.cache.get(birthday.User);
                if (member) {

                    let birthdayrole = await guild.roles.cache.get(data.Role)

                    if (birthdayrole) {
                        try {
                            member.roles.add(birthdayrole);
                        } catch {}
                    }
                    
                }

                await birthdayschema.updateMany({ User: birthday.User, Guild: birthday.Guild }, { $set: { HasRoleSince: Date.now() }});

            }

        })
    }
}, 1000 * 10);

// auto delete

const deleteMessagesInChannel = async (guildId, channelId) => {
    try {
      const guild = await client.guilds.fetch(guildId);
      const channel = guild.channels.cache.get(channelId);
  
      if (channel && channel instanceof TextChannel) {
        const messages = await channel.messages.fetch({ limit: 100 });
        const nonPinnedMessages = messages.filter(message => !message.pinned);
        await channel.bulkDelete(nonPinnedMessages);
      }
    } catch (error) {
      console.error('Error deleting messages:', error);
    }
  };
  
  const scheduleMessageDeletion = () => {
    setInterval(async () => {
      try {
        const data = await AutoDeleteSchema.find();
        for (const setup of data) {
          await deleteMessagesInChannel(setup.guildId, setup.channelId);
        }
      } catch (error) {
        console.error('Error deleting messages:', error);
      }
    }, 1 * 60 * 1000); // 1 minute in milliseconds
  };
  
  scheduleMessageDeletion();

  // messag reactor
client.on(Events.MessageCreate, async message => {
    const data = await reactor.findOne({ Guild: message.guild.id, Channel: message.channel.id});
    if (!data) return;
    else {
        message.react(data.Emoji).catch(async err => {
            const owner = await message.guild.members.cache.get(message.guild.ownerId);
            await owner.send({ content: `Hello there, it looks like i have found an error with the reactor system for your server - **${message.guild.name}** - and i thought i would bring it to your attention: \`❌ ${err}\``})
        })
    }
})

