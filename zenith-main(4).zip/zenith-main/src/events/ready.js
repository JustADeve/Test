const mongoose = require ('mongoose') //npm i mongoose@6.0.2
const mongodbURL = process.env.MONGODBURL;
const { ActivityType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log('Client Is Now Ready To Use!')
        client.user.setStatus("idle");
        client.user.setActivity({ name: '/help | Summer Build', type: ActivityType.Watching })

        setInterval(client.checkUpdates, 30000)

        if (!mongodbURL) return;
        
        mongoose.set('strictQuery', false);
        await mongoose.connect(mongodbURL || ``, {
            keepAlive: true,
            useNewUrlParser: true,
            useUnifiedTopology: true,
        })

        if (mongoose.connect) {
            console.log('Database is up and running!')
        }

    }
}

